# -*- coding: cp1252 -*-
# MUI_class.py



try:
    import Tkinter as tk
except ImportError:
    import tkinter as tk
    
import MUI_support


class Chk_Positionne:
    """ Positionne un Checkbox
    Note : positionne che, variable(du Checkbox) en cherchant search 
    dans srcchaine(mise en majuscule) """
    def __init__(self):
        pass
    def CP(self, lachaine, search, che):
        #self.leche = che
        che.set("0")
        if lachaine.upper().find(search) > -1:
            che.set("1")
            

class Check_IfAuthorizedChar:
    """ Teste si un caract�re interdit est saisi dans un Entry qui prend la
    couleur rouge si le caract�re est interdit """
    def __init__(self):
        pass
    def CC(self, LaEntry, NormalColor):
        if len(LaEntry.get()) == 0:
            LaEntry.configure(background=NormalColor)
            return True
        #"u" pour convertir en unicode
        #interdits = u"=[],��������������\"\'\\"  
        #CorrectChar = True
        #for char in LaEntry.get():
            #P = interdits.find(char)
            #if P > -1:
                #CorrectChar = False
        #if CorrectChar == True:
            #LaEntry.configure(background=NormalColor)
        #else:
            #LaEntry.configure(background="red")
            #MUI_support.BadActionInfo("Don't use [ ] , \" \' \\ and special characters")
        #return CorrectChar
        char = LaEntry.get()[-1:]
        autorise = "azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN" + \
        "_/#$%?&()0123456789 "
        CorrectChar = False
        try:
            if autorise.find(char) > -1:
                CorrectChar = True
                LaEntry.configure(background=NormalColor)
        except:
            pass
        if CorrectChar == False:
            LaEntry.configure(background="red")
            MUI_support.BadActionInfo("You can only use numbers, letters and . _ # $ % ? & ( ) /")
        return CorrectChar
        
    
class Str_Extract:
    """Extraction dans "chaine" par les delimiteurs "avant" et "apres".
    Si le resultat est vide ou en cas d'erreur, "v_defaut" est retourn�.
    Note : dysfonctionnement si"apres" est le dernier caract�re de chaine """
    def __init__(self):
        pass
    def SE(self, chaine, avant, apres, v_defaut):
        dep=chaine.find(avant)
        if dep == -1:
            return v_defaut
        lon = len(avant)
        fin = chaine.find(apres , dep)
        trouve=chaine[dep+lon:fin]
        try:
            trouve=chaine[dep+lon:fin]
            if trouve == "":
                trouve=v_defaut
        except:
            trouve=v_defaut
        return trouve
