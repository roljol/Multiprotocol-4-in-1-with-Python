#! /usr/bin/env python
#-*- coding: utf-8 -*-
#
# Abandonné :
# Bouton pour tester si les choix sont corrects NON

# Ajouter boutons pour remonter ou descendre une ligne dans LbxChoisi NON

# A faire :
#Pouvoir insérer du code (comme pour moi voir les "rj" avec ma radio PPM)
#Pouvoir charger config par défaut pour Serial et pour PPM

# Questions :
#Config par défaut : Serial ou PPM ? Serial
#Pascal, doit'il y avoir obligattoirement un transmitter déclaré ? en Srrial inutile
#Section importante : PROTOCOLS TO INCLUDE dans config.h seulement pour Serial ? NON
#En mode Serial les min et max_10 sont importants ? NON
#Pour un fabricant existe t'il plusieurs RfComponants.INO NON
#exception Q2X2 = CX10_NRFL24L01_INO ? dans Multiprotocol.h. ça m'ennuie
#Pourquoi //#define TRAXXAS_CYRF6936_INO pas #define dans _C..h ? Parce que prtocole pas terminé
#Tolérance +/- 300 pour les min et max_100 ? voir Multiprotocol.INO/Interruption PPM
#Si STM32 il y a de la mémoire pour tout VU
#Les RF components à valider si la carte 4-en-1 les possède ou s'ils ont utilisés dans les récepteurs
#*** Conseils de Pascal ci-dessous ***
#Si Serial pas de transmitter (donc grisé) FAIT
#Si Serial : les Bank ne servent à rien, la radio envoie les paramètres VU
#Télémétrie : par défaut tous Protocol activé VU
#Télémétrie : il faut soit Multi_status soit multi_telemetry soit rien VU
#Telemetry : INVERT coché par défaut
#RCmodel/Rx_num : de 0 à 15 (par défaut : 0). Rôle : après Bind ne pas
# interférer avec un autre récepteur
#Par défaut : cocher les 4 RF_component(s)
#Section importante : PROTOCOLS TO INCLUDE dans config.h (seulement pour Serial)
# au moment de la synthèse (voir Multiprotocol.h ?) A FAIRE
#Par exemple : en mode PPM, si  {PROTO_FLYSinfoKY,Flysky,0,P_HIGH,NO_AUTOBIND ,0}
# alors il faut #define	FLYSKY_A7105_INO
# exception Q2X2 = CX10_NRFL24L01_INO

#*** Mes commentaires au créateur de Page ***
#Relative : ce serait mieux de pouvoir décider pour relx, rely
#Erreur avec un menu coché
#Si menu créé alors hauteur Toplevel1 n'est plus la bonne lors de
#réouverture de Page FAIT le 12/12/18

#*** FONCTIONS ***
# AddInList : Renseigne une liste avec les valeurs choisies
# AllPpmParameters : Valide-Invalide ce qui est relatif à PPM
# AllSerialTypeProtocole : Pour INVERT, MULTI_TELEMETRY, MULTI_STATUS
# AllTransmittersState : Si Serial pas de transmitter (donc grisé)
# BadActionInfo( : Affiche le message concernant une erreur et emet un bip
# ChanelsOrderVerify : Vérifie l'ordre des canaux et retourne False si erreur
# ChanelsReverseVerifyAndCorrect : Vérifie Chanels/Reverse et corrige si nécessaire
# CheckIfAuthorizedChar.CC : Test si une un caractère interdit est saisi dans un Entry
# Default_Values : Mise à blanc des textes et valeurs par défaut des widgets
# DelInList : Supprime la ligne sélectionnée de LbxChoisi
# destroy_window : ermer la fenêtre et quitter le programme
# DisplayAddInfo( : Affiche une aide supplémentaire à l'aide de LbfAddInfo+LblAddInfo
# DisplayGeneral : Renseigne les widget pour la configuration générale
# DisplayLoadedCfg( : Adapter les textes de LbfGalConfig et LbfConfigChoix
# DisplayMsg : Affiche un message à l'aide d'un widget Message
# DisplayRcModel : renseigne les widget pour la configuration du RC_model
# FileInList : Charger un fichier dans une liste
# File_InsertString : Insère une chaîne (normalement plusieurs lignes) dans un fichier texte
# File_LoadCfg : Charge et affiche config_bankX.txt
# File_ProtoInCombobox : protocoles et sous-protocoles dans un combobox
# File_ReadConfiguration : Lit les noms donnés aux configurations
# File_ReplaceString : Remplace une ligne d'un fichier texte
# File_RfComponent_Proto : Renseigner list_Rf_Proto contenant les relation RF components/PROTO_..
# File_SavGeneral : Sauve la configuration générale dand "general.txt"
# File_SavRcModels( : Sauvegarde la liste dans CfgX/config_bankX.txt
# HelpInfo : Affiche un message d'aide
# init : Initialisation lors de l'appel du module
# LedOnOff( : Allume LED concernée et éteint les autres de même type
# LimitLen :Limiter le nb de car dans un widget Entry
# ModifIndique : Ajoute ou retire " [*]" au text d'un labelframe
# PpmMinMaxVerify : Verifie si les min_100.. sont numériques et s'ils existent
# QuitYesNo : Demander avant de quitter ce programme
# RcModelInsertion : Retourne le contenu des 5 Bank de MUI ou "FAUX" si problème trouvé
# ReverseCorrige : Enlève les doublons saisis pour les Reverse
# RF_ComponentVerify : Vérifie si au moins un RF_Component est choisi
# StrListExtration : Dans une liste, recherche lachaine et retourne son complément
# set_Tk_var : Initialisation des variables
# Synthese : Créer _MyConfig.h avec les nouveaux codes
# Telemetry_ProtocolVerify : Il faut un moins un protocole si la télémétrie est validée
# Valorise : Efface puis insère une valeur(texte) dans un widget
# WidgetsValidation : Valide des boutons en fonction de la situation

import sys, os, string
from shutil import copyfile

import MUI_class
CheckIfAuthorizedChar = MUI_class.Check_IfAuthorizedChar()
ChkPositionne = MUI_class.Chk_Positionne()
StrExtract = MUI_class.Str_Extract()

try:
    import Tkinter as tk
except ImportError:
    import tkinter as tk

try:
    import ttk
    import tkMessageBox
    import tkFileDialog
    py3 = False
except ImportError:
    import tkinter.ttk as ttk
    from tkinter import filedialog
    from tkinter import messagebox
    py3 = True


# Initialisation des variables
def set_Tk_var():
    global Vsignal			#Pour SERIAL ou PPM
    Vsignal = tk.StringVar()
    global Vtelemetry			#Pour la télémétrie
    Vtelemetry = tk.StringVar()
    global che10                        #Pour FailSafe Serial Only
    che10 = tk.StringVar()
    global che11                        #Pour DSM_THROTTLE_KILL_CH 15
    che11 = tk.StringVar()
    global che20                        #Pour Low_Power A7105
    che20 = tk.StringVar()
    global che21
    che21 = tk.StringVar()
    global che22
    che22 = tk.StringVar()
    global che23
    che23 = tk.StringVar()
    global che24                        #Pour USE_A7105_CH15_TUNING
    che24 = tk.StringVar()
    global che30                        #Pour DSM_MaxThrow
    che30 = tk.StringVar()
    global che31
    che31 = tk.StringVar()
    global che32                        #Pour OrangeTxBlue
    che32 = tk.StringVar()
    global Vtx				#Pour RadioButton des transmitters
    Vtx = tk.StringVar()
    global che42                        #Pour CheckBox INVERT_TELEMETRY
    che42 = tk.StringVar()
    global che43                        #Pour CheckBox MULTI_TELEMETRY
    che43 = tk.StringVar()
    global che44                        #Pour CheckBox MULTI_STATUS
    che44 = tk.StringVar()
    global che45                        #Pour FailSafe (ancien STM32)
    che45 = tk.StringVar()
    global che46                        #Pour Sport polling
    che46 = tk.StringVar()
    global che49                        #Pour Boot loader
    che49 = tk.StringVar()
    global che50                        #Pour protocole télémétrie AFHDS2A_FW
    che50 = tk.StringVar()
    global che51
    che51 = tk.StringVar()
    global che52
    che52 = tk.StringVar()
    global che53
    che53 = tk.StringVar()
    global che54
    che54 = tk.StringVar()
    global che55
    che55 = tk.StringVar()
    global che56
    che56 = tk.StringVar()
    global che57
    che57 = tk.StringVar()
    global che58
    che58 = tk.StringVar()
    global che59
    che59 = tk.StringVar()
    global che60
    che60 = tk.StringVar()
    global che61
    che61 = tk.StringVar()
    global che62
    che62 = tk.StringVar()
    global che63                        #Pour protocole télémétrie FUTUR2
    che63 = tk.StringVar()
    global che74			#Pour CheckBox A7105
    che74 = tk.StringVar()
    global che75			#Pour CheckBox CYRF6936
    che75 = tk.StringVar()
    global che76			#Pour CheckBox CC2500
    che76 = tk.StringVar()
    global che77			#Pour CheckBox NRF24L01
    che77 = tk.StringVar()
    #global Vrxnum			#Pour Rx_num
    #Vrxnum = tk.StringVar()
    global Vpower			#Pour Power
    Vpower = tk.StringVar()
    global Vautobind			#Pour AutoBind
    Vautobind = tk.StringVar()
    global Vloadbank
    Vloadbank = tk.StringVar()
    global Vsavcfg
    Vsavcfg = tk.StringVar()
    global Vsavbank
    Vsavbank = tk.StringVar()
    global Version
    Version="Informations : V0.1.0"     #images ajoutées aux boutons
    global VtxMem
    VtxMem = "CUSTOM"
    global VsignalMem
    VsignalMem = "PPM"
    global VtelemetryMem
    VtelemetryMem = "NO"
    global GalModif
    GalModif = False
    global RcmModif
    RcmModif = False
    global VautobindMem
    VautobindMem = "NO"
    global VpowerMem
    VpowerMem = "P_HIGH"
    global MinMaxAuto
    MinMaxAuto = tk.StringVar()
    global RcModelListSorted
    RcModelListSorted = tk.StringVar()
    global ProtoSubProtoListSorted
    ProtoSubProtoListSorted = tk.StringVar()
    global LangEnglish
    LangEnglish = tk.StringVar()
    global LangFrench
    LangFrench = tk.StringVar()
    global Clipboard
    Clipboard = ""
    
#*** Les boutons ***********************************************************
# Bouton pour mes essais
def BtnTest_Survol(e):
    HelpInfo("[Test] = don't use this button")
def BtnTest_Lclic(p1):
    print w.LbxChoisi.curselection()


# Bouton pour ajouter une config RC_model dans LbxChoisi
def BtnAdd_Lclic(p1):
    #print ("def BtnAdd_Lclic")
    if w.BtnAdd.cget("state") <> "disabled":
        AddInList(w.LbxChoisi)
        ModifIndique("RC model", True)
def BtnAdd_Survol(p1):
    HelpInfo("[Accept, Add RC model >] = add RC model configuration at \
the end of the list on the right")

# Charger la configuration générale No1
def BtnCfg1Gal_Lclic(p1):
    BtnCfgGal_Lclic_Sub1("Cfg1", w.LblCfg1Gal)
def BtnCfg1RcModel_Lclic(p1):
    BtnCfgRcModel_Lclic_Sub1("Cfg1", "1", w.LblCfg1RcModel)
def BtnCfg1_Lclic(e):
    BtnCfg1Gal_Lclic(e)
    BtnCfg1RcModel_Lclic(e)

# Charger la configuration générale No2
def BtnCfg2Gal_Lclic(p1):
    BtnCfgGal_Lclic_Sub1("Cfg2", w.LblCfg2Gal)
def BtnCfg2RcModel_Lclic(p1):
    BtnCfgRcModel_Lclic_Sub1("Cfg2", "2", w.LblCfg2RcModel)
def BtnCfg2_Lclic(e):
    BtnCfg2Gal_Lclic(e)
    BtnCfg2RcModel_Lclic(e)

# Charger la configuration générale No3
def BtnCfg3Gal_Lclic(p1):
    BtnCfgGal_Lclic_Sub1("Cfg3", w.LblCfg3Gal)
def BtnCfg3RcModel_Lclic(p1):
    BtnCfgRcModel_Lclic_Sub1("Cfg3", "3", w.LblCfg3RcModel)
def BtnCfg3_Lclic(e):
    BtnCfg3Gal_Lclic(e)
    BtnCfg3RcModel_Lclic(e)

# BtnCfgX (charger configurations générales et RC model) survolés
def BtnCfgX_Survol(e):
    HelpInfo("[1 or 2 or 3] = loading general and RC model configurations")

# Sous-fonction pour les BtnCfgXGal_Lclic
def BtnCfgGal_Lclic_Sub1(Cfg, lelabel):
    global GalModif
    loadok = True
    if GalModif:
        loadok = False
        if tkMessageBox.askyesno("General configuration", "Continue wihtout save ?"):
            loadok = True
            GalModif = False
    if loadok:
        File_LoadGeneral(Cfg)
        LedOnOff(lelabel, "General")
        ModifIndique("General", False)

# BtnCfgXGal (charger configurations générales) survolés
def BtnCfgXGal_Survol(e):
    HelpInfo("[General] (in \"Gal:X | RC_model:X | Bank:X\") = load the general \
configuration marked above")

def BtnCfgXRcModel_Survol(e):
    HelpInfo("[RC model] (in \"Gal:X | RC_model:X | Bank:X\") = load the RC model \
configuration marked above")
             
# BtnCfgRcModel_Lclic_Sub1
#  File_LoadCfg
#   FileInList
#     DisplayLoadedCfg
#     RbtSavCfgGreen
#   WidgetsValidation
# Charge le config RCmodel demandée si il n'y a pas de modification en cour sinon
# demande l'autorisation.
def BtnCfgRcModel_Lclic_Sub1(Cfg, Num, lelabel):
    global RcmModif
    loadok = True
    if RcmModif:
        loadok = False
        if tkMessageBox.askyesno("RC model configuration", "Continue wihtout save ?"):
            loadok = True
            RcmModif = False
    if loadok:
        File_LoadCfg(Cfg, Num, Vloadbank.get())
        LedOnOff(lelabel, "RcModel")
        ModifIndique("RC model", False)

def BtnCfgDefaut_Lclic(p1):
    File_LoadGeneral("Cfg0")
    File_LoadCfg("Cfg0", "1", "1")
    #LedOnOff(None, "General and RcModel")       #Eteindre les LEDs
def BtnCfgDefaut_Survol(p1):
    #sys.stdout.flush()
    HelpInfo("[Default] = load default values")
    
# Bouton pour supprimer une ligne de LbxChoisi
def BtnDel_Lclic(p1):
    if w.BtnDel.cget("state") <> "disabled":
        DelInList(w.LbxChoisi)
        ModifIndique("RC model", True)
def BtnDel_Survol(p1):
    HelpInfo("[Del RC model >] = delete the selected line")
    
# Descendre ligne dans LbxChoisi
def BtnDown_Lclic(p1):
    Ltuple = w.LbxChoisi.curselection()
    if Ltuple == ():
        return
    tmp = w.LbxChoisi.get(Ltuple)
    w.LbxChoisi.delete(Ltuple)
    idx = Ltuple[0]+1
    w.LbxChoisi.insert(idx, tmp)
    w.LbxChoisi.selection_set(idx)
    WidgetsValidation()
def BtnDown_Survol(e):
    HelpInfo("[Down] = go down the selected line of 1 level")
    
# Bouton pour quitter
def BtnExit_Lclic(p1):
    destroy_window()

# Le clipboard
def BtnInClipBoard_Lclic(p1):
    global Clipboard
    if w.BtnInClipBoard.cget("state") <> "disabled":
        line=w.LbxChoisi.curselection()
        Clipboard = w.LbxChoisi.get(line)
        #WidgetsValidation()
def BtnInClipBoard_Survol(p1):
    HelpInfo("[< Clipboard] = copy the selected line in internal clipboard")
def BtnInList_Lclic(p1):
    global Clipboard
    if w.BtnInList.cget("state") <> "disabled":
        w.LbxChoisi.insert("end", Clipboard)
        WidgetsValidation()
def BtnInList_Survol(p1):
    HelpInfo("[> Clipboard] = copy internal clipboard at the end of RC model list ")
    
def BtnIndicDirMp_Lclic(p1):
    MonRep = os.getcwd()
    lefic =""
    rep = tkFileDialog.askdirectory(title="Indicate Multiprotocol directory", \
    initialdir=MonRep)
    if rep <> "":
        w.LblDirMp2.configure(text=rep)
        w.BtnSavConfig.configure(state="normal")
        w.BtnSavConfig2.configure(state="normal")
def BtnIndicDirMp_Survol(p1):
    HelpInfo("[Indicate] = indicate the Multiprotocol folder (required). Then click on [Save MUI config.]")

# Refresh
def BtnRefresh_Lclic(e):
    modele = "*" + w.EnyBrand.get().ljust(10," ") + "|" \
    + w.EnyRcModel.get().ljust(20," ") + "[PROTOCOL=" + \
    w.EnyProtocol.get() + ",SUB_PROTOCOL=" + w.EnySubProtocol.get() + \
    ",RX_Num=" + w.SbxRxNum.get() + ",Power=" + Vpower.get() + \
    ",Auto_Bind=" + Vautobind.get() + ",Option=" + w.SbxOption.get() + \
    ",ConfiguratorName=" + w.EnyConfigurateur.get() + \
    ",FUTUR1=" + w.EnyFutur1.get() + "]"
    Ltuple = w.LbxChoisi.curselection()
    if (Ltuple == ()):      #Par précaution
        return
    #tmp = w.LbxChoisi.get(Ltuple)
    w.LbxChoisi.delete(Ltuple)
    idx = Ltuple[0] #-1
    w.LbxChoisi.insert(idx, modele)
    w.LbxChoisi.selection_set(idx)
    ModifIndique("Rc model", True)
def BtnRefresh_Survol(e):
    HelpInfo("[Refresh] = Refreshes the selected line with the displayed parameters")
    
# Renseigner configuration.txt
def BtnSavConfig_Lclic(p1):
    if w.BtnSavConfig.cget("state") == "disabled":
        return 0
    f = open("./Cfg0/configuration.txt",'w')
    f.write(Version + "\n")
    f.write(w.EnyCfg1.get() + "\n")
    f.write(w.EnyCfg2.get() + "\n")
    f.write(w.EnyCfg3.get() + "\n")
    f.write(w.LblDirMp2.cget("text") + "\n")
    f.write("MinMaxAuto=" + MinMaxAuto.get() + "\n")
    f.write("RcModelListSorted=" + RcModelListSorted.get() + "\n")
    f.write("ProtoSubProtoListSorted=" + ProtoSubProtoListSorted.get() + "\n")
    f.write("LangFrench=" + LangFrench.get() + "\n")
    f.close()
    w.BtnSavConfig.configure(state="disabled")
    w.BtnSavConfig2.configure(state="disabled")
def BtnSavConfig_Survol(p1):
    HelpInfo("[Save MUI config.] = save MUI configuration (as in the File menu, necessary after [Indicate])")
def BtnSavConfig_Rclic(e):
    msg = \
"To save the MUI configuration.\n" + \
"- cfg names in \" Gal : X | RC_model : X | Bank : X\" frame\n" + \
"- directory of Multiprotocol.ino\n" + \
"- ...\n" + \
"- Option menu" + \
"@french@\
Pour sauvegarder la configuration de ce programme.\n" + \
"- les noms que vous avez donnés aux configurations dans le cadre \
\" Gal : X | RC_model : X | Bank : X\"\n" + \
"- le répertoire de Multiprotocol.ino\n" + \
"- ...\n" + \
"- le menu Option"
    DisplayAddInfo("Save MUI config.", msg, 6, "Top")

# Bouton pour sauvegarder la configuration générale
def BtnSavGal_Lclic(p1):
    if File_SavGeneral(Vsavcfg.get()) == True:
        ModifIndique("General", False)
def BtnSavGal_Survol(p1):
    HelpInfo("[General] (in frame \'Save in CfgX BankX\') = save the chosen \
general configuration")
def BtnSavGal_Rclic(p1):
    msg = \
"(in the \"Save in CfgX BankX\" frame)\n" + \
"Save the current General configuration." + \
"@french@\
(dans le cadre \"Save in CfgX BankX\")\n" + \
"Sauvegarde la configuration générale affichée."    
    DisplayAddInfo("General", msg, 3, "Top")

#Bouton pour sauvegarder la liste RCmodel
def BtnSavRcModel_Lclic(p1):
    if w.BtnSavRcModel.cget("state") <> "disabled":
        if File_SavRcModels(Vsavcfg.get(), Vsavbank.get()) == True:
            ModifIndique("RC model", False)
def BtnSavRcModel_Survol(p1):
    HelpInfo("[Rc model] (in frame \'Save in CfgX BankX\') = save the chosen \
RC model configuration")
def BtnSavRcModel_Rclic(p1):
    msg = \
"(in the \"Save in CfgX BankX\" frame)\n" + \
"Save the current Rc model configuration." + \
"@french@\
(dans le cadre \"Save in CfgX BankX\")\n" + \
"Sauvegarde la configuration des \"RC model\" affichée."
    DisplayAddInfo("RC model", msg, 3, "Top")

def BtnSav_Survol(e):
    HelpInfo("[S] (in frame \'Save in CfgX BankX\') = save the chosen \
General and RC model configurations")
def BtnSav_Lclic(e):
    BtnSavGal_Lclic(e)
    BtnSavRcModel_Lclic(e)    
   
# Bouton pour faire la synthese
def BtnSynthese_Lclic(p1):
    Synthese()
def BtnSynthese_Rclic(e):
    msg = \
    "Prepares the programming that will be done by the Arduino software\n\n" + \
    "Create the _MyConfig.h and adapt _Config.h files.\n" + \
    "In _MyConfg.h, will be written :\n" + \
    "- all #undef and all #define necessary for the programming of the 4-in-1 card\n" + \
    "In _Config.h, will be written :\n" + \
    "- #define USE_MY_CONFIG\n" + \
    "- all RC model parameters for each bank\n" + \
    "The general and RC_model configurations displayed are taken into account." + \
    "@french@" + \
    "Prépare la programmation qui sera effectuée par le logiciel Arduino\n\n" + \
    "Crée _MyConfig.h et adapte _Config.h files.\n" + \
    "Dans _MyConfg.h, seront écrits :\n" + \
    "- tous les #undef et #define nécessaires à la programmation du module 4-in-1\n" + \
    "Dans _Config.h, seront écrits :\n" + \
    "- #define USE_MY_CONFIG\n" + \
    "- tous les paramètres RC model pour chaque \"bank\"\n" + \
    "Les configurations générale et RC_model affichées sont prise en compte."
    DisplayAddInfo("Synthesize", msg, 11, "Top")
def BtnSynthese_Survol(e):
    HelpInfo("[Synthesize] : create _MyConfig.h and adapt _Config.h.")
    
def BtnUp_Lclic(p1):
    Ltuple = w.LbxChoisi.curselection()
    if (Ltuple == ()) or (Ltuple == (0,)):
        return
    tmp = w.LbxChoisi.get(Ltuple)
    w.LbxChoisi.delete(Ltuple)
    idx = Ltuple[0]-1
    w.LbxChoisi.insert(idx, tmp)
    w.LbxChoisi.selection_set(idx)
    WidgetsValidation()
def BtnUp_Survol(e):
    HelpInfo("[Up] : go up the selected line of 1 level")
#***************************************************************************

#*** Les chkbutton *********************************************************
# A7105_CH15_TUNING
def ChkA7105Ch15Tuning_Rclic(p1):
    msg = \
"This is required in rare cases where some A7105 modules and/or RXs have \
an inaccurate crystal oscillator.\n" + \
"If using Serial mode only (for now), you can use CH15 to find the right \
tuning value. -100%=-300, 0%=default 0, +100%=+300.\n" + \
"Validate the checkbutton to enable this feature." + \
"@french@\
Rarement nécessaire. A utiliser lorsque l'oscillateur de l'émetteur ou du \
récepteur a besoin d'être ajusté.\n" + \
"Utilisable seulement en mode Serial (pour le moment), vous pouvez l'utiliser \
pour chercher le bon ajustement. -100% = -300, +100% = +300, par défaut : 0%.\n" + \
"Validez le checkbutton pour activer cette fonctionnalité."
    DisplayAddInfo("A7105_CH15_TUNING", msg, 5, "Bottom")
def ChkA7105Ch15Tuning_Survol(e):
    HelpInfo("A7105_CH15_TUNING = to pair the Tx et Rx frequencies")

def ChkAFHDS2A_FW_Rclic(p1):
    msg = \
"Forward received telemetry packet directly to TX to be decoded by ersky9x \
and OpenTX" + \
"@french@\
Envoyer les trames de télémétrie à l'émetteur pour qu'elles soient décodées \
par ersky9x et OpenTX"
    DisplayAddInfo("AFHDS2A_FW (telemetry)", msg, 3, "Bottom")

def ChkAFHDS2A_HUB_Rclic(p1):
    msg = \
"Use FrSkyD Hub format to send basic telemetry to TX like er9x" + \
"@french@\
Pour envoyer une télémétrie basique de type er9x"
    DisplayAddInfo("ChkAFHDS2A_HUB (telemetry)", msg, 3, "Bottom")

def ChkBAYANG_HUB_Rclic(p1):
    msg = \
"Use FrSkyD Hub format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyD Hub."
    DisplayAddInfo("BAYANG_HUB (telemetry)", msg, 3, "Bottom")

def ChkBUGS_HUB_Rclic(e):
    msg = \
"Use FrSkyD Hub format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyD Hub."
    DisplayAddInfo("BUGS_HUB (telemetry)", msg, 3, "Bottom")

# CABELL_HUB
def ChkCABELL_HUB_Rclic(e):
    msg = \
"Use FrSkyD Hub format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyD Hub."
    DisplayAddInfo("CABELL_HUB (telemetry)", msg, 3, "Bottom")

# HITEC_FW
def ChkHITEC_FW_Rclic(e):
    msg = \
"Under development: Forward received telemetry packets to \
be decoded by ersky9x and OpenTX" + \
"@french@\
En développement, les trames de télémétrie reçues sont décodées avec \
ersky9x et OpenTX"
    DisplayAddInfo("HITEC_FW (telemetry)", msg, 3, "Bottom")

# HITEC_HUB
def ChkHITEC_HUB_Rclic(e):
    msg = \
"Use FrSkyD Hub format to send basic telemetry to the radios which \
can decode it like er9x, ersky9x and OpenTX" + \
"@french@\
Utiliser le format FrSkyD Hub pour envoyer une télémétrie de base aux \
radios qui peuvent la décoder comme er9x, ersky9x et OpenTX"
    DisplayAddInfo("HITEC_HUB (telemetry)", msg, 3, "Bottom")
#Commentaire de Pascal :
#C'est pas le récepteur qui change le format mais moi dans le module qui
# le transforme et le renvoi dans un format connu frsky hub. C'est l'un des
# premiers protocol avec télémètrie donc beaucoup de radio savent le décoder.
    
def ChkHUBSAN_HUB_Rclic(e):
    msg = \
"Use FrSkyD Hub format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyD Hub."
    DisplayAddInfo("HUBSAN_HUB (telemetry)", msg, 3, "Bottom")
    
# Check for boot loader
def ChkCheckForBootLoader_Rclic(p1):
    msg = \
"Allow flashing multimodule directly with TX(erky9x or opentx) \
modified firmwares)\n" + \
"Instructions: https://github.com/pascallanger/DIY-Multiprotocol-TX-Module/tree/master/\n" + \
"BootLoaders#compiling--uploading-firmware-with-the-flash-from-tx-bootloader\n" + \
"Requires a compatible bootloader or upload method to be selected when you use the \
Multi 4-in-1 Boards Manager definitions.\
@french@\
Vous donne la possibilité de mettre à jour le module 4_in_1 à partir de l'émetteur (erky9x or opentx)\n" + \
"Instructions: https://github.com/pascallanger/DIY-Multiprotocol-TX-Module/tree/master/\n" + \
"BootLoaders#compiling--uploading-firmware-with-the-flash-from-tx-bootloader\n" + \
"Nécessite un \"bootloader\" compatible ou une méthode de téléchargement compatible avec \
la définition du gestionnaire Multi 4-in-1."
    DisplayAddInfo("Check for boot loader", msg, 5, "Bottom")
def ChkCheckForBootLoader_Survol(p1):
        HelpInfo("[Check for boot loader] : allow flashing yor 4_in_1 card with TX (if it's possible)")

# ChkDSM_MAX_THROW
def ChkDSM_MAX_THROW_Rclic(p1):
    msg = \
"The DSM protocol is using by default the Spektrum throw of 1100..1900us @100% and 1000..2000us @125%.\n" + \
"For more throw, 1024..1976us @100% and 904..2096us @125%, validate the.\n" + \
"Be aware that too much throw can damage some UMX servos. To achieve standard throw in this mode use a \
channel weight of 84%.\
@french@\
Le protocole DSM utilise par défaut le \"débattement Spektrum\" de \
1100..1900us @100% et 1000..2000us @125%.\n" + \
"Pour plus de débattement, 1024..1976us @100% and 904..2096us @125%, validez le.\n" + \
"Sachez que trop de débattement peut endommager une servo-commande UMX. 84% est \
une valeur standard pour le \"channel weight\"."
    DisplayAddInfo("DSM_MaxThrow", msg, 5, "Bottom")

def ChkHUB_Rclic(p1):
    msg = \
"Use FrSkyD Hub format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyD Hub"
    DisplayAddInfo("HUB (telemetry)", msg, 3, "Bottom")
    
# ChkA7105 : si invalidé, invalide aussi ChkA7105Ch15Tuning
def ChkA7105_Lclic(p1):
    if che74.get() <> "1":      #ChkA7105 est en train de passer à "1",
        w.ChkA7105Ch15Tuning.configure(state="normal")      #valider ChkA7105Ch15Tuning
    else:
        w.ChkA7105Ch15Tuning.configure(state="disabled")    #invalider ChkA7105Ch15Tuning

def ChkA7105LowPower_Lclic(p1):
    if che20.get() <> "1":      #ChkA7105LowPower est en train de passer à "1",
        if che74.get()=="0":    #donc vérif que ChkA7105="1"
            BadActionInfo("You will have to validate the RF component above")
def ChkCYRF6936LowPower_Lclic(p1):
    if che21.get() <> "1":      #ChkCYRF6936LowPower est en train de passer à "1",
        if che75.get()=="0":    #donc vérif que ChkCYRF6936="1"
            BadActionInfo("You will have to validate the RF component above")
def ChkCC2500LowPower_Lclic(p1):
    if che22.get() <> "1":      #ChkCC2500LowPower est en train de passer à "1",
        if che76.get()=="0":    #donc vérif que ChkCC2500="1"
            BadActionInfo("You will have to validate the RF component above")
def ChkNRF24L01LowPower_Lclic(p1):
    if che23.get() <> "1":      #ChkNRF24L01LowPower est en train de passer à "1",
        if che77.get()=="0":    #donc vérif que ChkNRF24L01="1"
            BadActionInfo("You will have to validate the RF component above")
def ChkXLowPower_Survol(p1):
    HelpInfo("[LowPow] : validate P_LOW(low power) for the corresponding \
RF component in RC model configuration")
def ChkLowPower_Rclic(p1):
    msg = \
"Low Power\n\n" + \
"Low power is reducing the transmit power of the multi module. This setting is \
configurable per model in PPM or Serial mode.\n" + \
"It can be activated when flying indoor or small models since the distance is \
short or if a model is causing issues when flying closed to the TX.\n" + \
"By default low power is completly disabled on all rf chips to prevent mistakes, \
but you can enable it.\
@french@\
Low Power\n\n" + \
"Pour réduire la puissance d'émission du Multi 4-e0-1. Ceci est \
paramétrable par modèle en mode Serial ou PPM.\n" + \
"Cette réduction peut être activée pour de l'aéromodélisme en salle lorsque les \
distances sont courtes ou si un modèle pose un problème de proximité avec un émetteur.\n" + \
"A vous de décider si vous en validez."
    DisplayAddInfo("LowPow", msg, 7, "Bottom")

def ChkDSM_Rclic(p1):
    msg = \
"Forward received telemetry packet directly to TX to be decoded by er9x, \
ersky9x and OpenTX" + \
"@french@\
Envoyer les informations de télémétrie à lémetteur qui les décodera (er9x, \
ersky9x and OpenTX)"
    DisplayAddInfo("DSM (telemetry)", msg, 3, "Bottom")
    
def ChkRF_Component_Rclic(p1):
    msg = \
"There are 4 RF components supported. Those that are not used can be \
invalidated must invalidate.\n" + \
"If a chip is not validated all associated protocols are automatically \
disabled.\n" + \
"(4-in-1 modules have all RF chips installed)\n" + \
"!!!If a RF chip is present it MUST be marked as installed!!! or weird \
things will happen, you have been warned." + \
"@french@\
Il y a 4 RF components (circuits spécialisés) supportés. \
Ceux qui ne sont pas utilisés peuvent être invalidés.\n" + \
"Si un circuit est invalidé tous les prorocoles associés sont automatiquement \
invalidés.\n" + \
"(le module 4-en-1 possède les 4 RF components)\n" + \
"!!!Si un RF component est présent il doit être validé!!! sinon \
d'étranges choses peuvent arriver. Vous êtes prévenus."
    DisplayAddInfo("RF_Components", msg, 6, "Bottom")

# FailSafe
def ChkFailSafe_Rclic(e):
    msg = \
"The module is using the same default failsafe values for all protocols \
which currently supports it:\n" + \
"Devo, WK2x01, SFHSS, HISKY/HK310 and AFHDS2A\n" + \
"All channels are centered except throttle which is forced low.\
@french@\
Le module utilise la même valeur de failsafe (mise en sécurité) pour tous les \
protocoles qu'il supporte :\n" + \
"Devo, WK2x01, SFHSS, HISKY/HK310 et AFHDS2A\n" + \
"Pour centrer tous les canaux sauf throttle (gaz) forcé à sa valeur minimale."
    DisplayAddInfo("FailSafe", msg, 4, "Bottom")
# FailSafe survolé
def ChkFailSafe_Survol(p1):
    HelpInfo("[FailSafe] : for protocols Devo, WK2x01, SFHSS, HISKY/HK310 and AFHDS2A")
# FailSafe Serial Only
def ChkFailSaveSerialOnly_Survol(p1):
    HelpInfo("[FailSafe Serial Only] : force #define FAILSAFE_SERIAL_ONLY \
if validated")
def ChkFailSaveSerialOnly_Rclic(p1):
    msg = \
"The radio using serial protocol can set failsafe data.\n" + \
"Two options are available:\n" + \
" a. replace the default failsafe data with serial failsafe data when \
they are received.\n" + \
" b. wait for the radio to provide failsafe before sending it. Enable \
advanced settings like \"FAILSAFE NOT SET\" or \"FAILSAFE RX\".\n" + \
"Option a. is the default since you have a protection even if no failsafe \
has been set on the radio.\n" + \
"You can force option b. by enabling checkbutton." + \
"@french@\
Une radio utilisant le mode Serial (série) peut gérer le failsafe \
(mise en sécurité).\n" + \
"2 options possibles :\n" + \
"a) remplacez les failsafe par défaut par des failsafe imposés qui sont \
pris en compte dès leurs réceptions.\n" + \
"b) attendre que la radio informe qu'un failsafe devient actif, puis envoyer \
des commandes de mise en sécurité. Cette façon de procéder a des similarités \
avec \"FAILSAFE NOT SET\" ou \"FAILSAFE RX\".\n" + \
"L'option a est la valeur par défaut puisque vous disposez d’une protection \
même si aucune mise en sécurité n’est envoyée par la radio."
    DisplayAddInfo("FailSafe Serial Only", msg, 8, "Bottom")

def ChkINVERT_TELEMETRY_Rclic(p1):
    msg = \
"To invert the polarity of the output telemetry serial signal.\n\n" + \
"This function takes quite some flash space and processor power on an atmega.\n" + \
"For OpenTX it must be enabled.\n" + \
"On a 9XR_PRO running ersky9x both commented and uncommented will work \
depending on the radio setting. Invert COM1 under the Telemetry menu.\n" + \
"On other addon/replacement boards like the 9xtreme board or the Ar9x \
board running ersky9x, you need to enabling.\n" + \
"For er9x it depends if you have an inverter mod or not on the telemetry \
pin. If you don't have an inverter disable the checkbutton." + \
"@french@\
Pour inverser la polarité du signal de télémétrie.\n\n" + \
"Cette fonction prend un peu d’espace flash et de puissance de processeur \
sur un atmega.\n" + \
"Pour les OpenTX elle doit être activée.\n" + \
"Avec un 9XR_PRO qui exécute ersky9x, les \"commented\" et \"uncommented\" \
fonctionnent selon le réglage de la radio. Inverser COM1 dans le menu \
Télémétrie.\n" + \
"Sur d’autres cartes de remplacement telles que la carte 9xtreme ou la \
carte Ar9x exécutant ersky9x, vous devez l'activer.\n" + \
"Pour er9x cela dépend si vous avez un mode inversion ou non sur la pin \
Telemetry. Si n'avez pas de mode inversion ne validez pas ce Checkbutton."
    DisplayAddInfo("INVERT", msg, 10, "Bottom")

# Multi Telemetry
def ChkMULTI_TELEMETRY_Lclic(p1):
    if che43.get() <> "1":      #Multi_Telemetry est en train de passer à "1",
        che44.set("0")          #donc obligatoirement Multi_Status doit passer à "0"
def ChkMULTI_TELEMETRY_Rclic(p1):
    msg = \
"Enable to send Multi status and allow OpenTX to autodetect the telemetry \
format.\n"+ \
"Supported by OpenTX version 2.2 RC9 and newer. NOT supported by er9x/ersky9x \
use MULTI_STATUS instead.\
@french@\
Pour activer le Multi statut et permettre à OpenTX de détecter \
automatiquement le format de télémétrie.\n"+ \
"Pris en charge par OpenTX version 2.2 RC9 et plus récente. NON \
supporté par er9x / ersky9x utilisez MULTI_STATUS à la place."
    DisplayAddInfo("Multi_Telemetry", msg, 4, "Bottom")

# Multi Status
def ChkMULTI_STATUS_Lclic(p1):
    if che44.get() <> "1":      #Multi_Status est en train de passer à "1",
        che43.set("0")          #donc obligatoirement Multi_Telemetry doit passer à "0"
def ChkMULTI_STATUS_Rclic(p1):
    msg = \
"Disable if you don't want to send Multi status telemetry frames \
(Protocol available, Bind in progress, version...)\n" + \
"Use with er9x/erksy9x, for OpenTX MULTI_TELEMETRY below is preferred instead" + \
"@french@\
Invalidez si vous ne voulez pas des trames de télémétrie Multi statut \
(Protocol available, Bind in progress, version...)\n" + \
"Pour une utilisation avec er9x/erksy9x et OpenTX MULTI_TELEMETRY il est \
préférable de valider ce Checkbutton."
    DisplayAddInfo("Multi_Status", msg, 4, "Bottom")

# NCC1701_HUB (telemetry)
def ChkNCC1701_HUB_Rclic(e):
    msg = \
"Use FrSkyD Hub format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyD Hub"
    DisplayAddInfo("NCC1701_HUB (telemetry)", msg, 3, "Bottom")

# OrangeTxBlue
def ChkOrangeTxBlue_Rclic(p1):
    msg = \
"If you compile for the OrangeRX TX module you need to select the correct \
board type.\n" + \
"By default the compilation is done for the GREEN board, to switch to \
a BLUE board validate the checkbutton." + \
"@french@\
Si vous compilez pour le module \"Orange TX\" vous devez sélectioner la \
bonne carte.\n" + \
"Par défaut, la compilation est basée sur la carte verte, pour l'utilisation \
d'une carte de couleur bleu, validez ce Checkbutton."
    DisplayAddInfo("OrangeTxBlue", msg, 4, "Bottom")

def ChkRF_Component_Survol(e):
    HelpInfo("RF_Component : a RF_Component used must be validated")

# SPORT (telemetry)
def ChkSPORT_Rclic(p1):
    msg = \
"Use FrSkyX SPORT format to send telemetry to TX" + \
"@french@\
Pour envoyer la télémétrie au format FrSkyX SPORT"
    DisplayAddInfo("SPORT (telemetry)", msg, 3, "Bottom")

# SportPolling
def ChkSportPolling_Rclic(e):
    msg = \
"SPORT_POLLING is an implementation of the same polling routine as XJT \
module for sport telemetry bidirectional communication.\n" + \
"This is useful for passing sport control frames from TX to RX\n(ex: \
changing Betaflight PID or VTX channels on the fly using LUA scripts with \
OpentX).\n" + \
"Using this feature requires to enabled INVERT_TELEMETRY as this TX output \
on telemetry pin only inverted signal.\n" + \
"!!!! This is a work in progress!!! Do not enable unless you want to test \
and report." + \
"@french@\
SPORT_POLLING est une implémentation de la même routine d'interrogation que \
celle du module XJT pour la communication bidirectionnelle de type sport.\n" + \
"C\'est utile pour passer le contrôle des trames \"sport control\" de lémetteur \
vers le récepteur.\n(ex: \
changement de Betaflight PID ou VTX channels à la volée pour l'utilisation \
d'un script LUA avec OpentX).\n" + \
"En cas d'utilisation, il faut valider INVERT_TELEMETRY en fonction de la pin \
d'inversion du signal de télémétrie.\n" + \
"!!!!En cour de développement!!! Ne pas valider sans avoir effectuer des tests."  
    DisplayAddInfo("Sport Polling", msg, 7, "Bottom")

# WaitForBind survolé
def ChkWaitForBind_Survol(p1):
    HelpInfo("[WaitForBind] : protection of people's model if AUTOBIND is enabled")
def ChkWaitForBind_Rclic(p1):
    msg = \
"If Autobind is enabled in the model config, this feature will not activate \
the selected protocol unless a bind is requested using bind \n" + \
"from channel or the GUI [Bind] button.\n" + \
"The goal is to prevent binding other people's model when powering up the \
TX, changing model or scanning through protocols." + \
"@french@\
Si Autobind est validé pour un modèle, le protocole concerné ne sera activé \
que si le bouton bind est pressé.\n" + \
"Le but est d'éviter de lier le modèle d'autres personnes lors de la mise \
en marche de l'émetteur, du changement de modèle ou de la numérisation \
lors d'un scan des protocoles."
    DisplayAddInfo("WaitForBind", msg, 4, "Bottom")
#***************************************************************************

#*** Les Combobox **********************************************************
#copier la sélection dans EnyProtocol et EnySubProtocol
def CbxProtocoles_Selected(p1):
    lachaine = w.CbxProtocoles.get()
    prot = lachaine[:15].rstrip()
    subp = lachaine[16:].rstrip()
    if lachaine <> "":
        Valorise(w.EnyProtocol, prot)
        Valorise(w.EnySubProtocol, subp)
def CbxProtocoles_Survol(p1):
    HelpInfo("Combinated entry list : list of know protocols, subprotocols \
(see Option/Sorted List for Protocols and Sub)")
def CbxProtocoles_Rclic(e):
    msg = \
"Preferably use the combobox dropdown list to choose protocols and \
corresponding sub-protocols.\n" + \
"Protocol and sub-protocols are from _Config.h" + \
"@french@\
De préférence, utilisez la liste déroulante du \"Combobox\" pour choisir les \
protocoles et sous-protocoles.\n" + \
"Les protocoles et sous-protocoles sont issus de _Config.h"
    DisplayAddInfo("Protocol, Sub protocol and combobox (list)", msg, 3, "Top")


#***************************************************************************

#*** Les command ***********************************************************
# Grise LblAfhds2aLqi si SbxAfhds2aLqi<5 et enclenche ModifIndique
def cmdAfhds2aLqi():
    #print ("def cmdFailSafe")
    if int(w.SbxAfhds2aLqi.get()) < 5:
        w.LblAfhds2aLqi.configure(state="disabled")
    else:
        w.LblAfhds2aLqi.configure(state="normal")
    ModifIndique("General", True)

# DSM_THROTTLE_KILL_CH
def cmdDsmThrottleKillCh():
    if int(w.SbxDSM_THROTTLE_KILL.get()) == 0:
        w.LblChkDSM_THROTTLE_KILL.configure(state="disabled")
    else:
        w.LblChkDSM_THROTTLE_KILL.configure(state="normal")
    ModifIndique("General", True)

# Grise LblFailSafe si SbxFailSafe=0 et enclenche ModifIndique
def cmdFailSafe():
    #print ("def cmdFailSafe")
    if int(w.SbxFailSafe.get()) == 0:
        w.LblFailSafe.configure(state="disabled")
    else:
        w.LblFailSafe.configure(state="normal")
    ModifIndique("General", True)

# Invalide un label si son spinbox correspondant vaut 0
def cmdForceTuning():
    #print("def cmdForceTuning")
    for key in ForceTuningLabels.keys():
        if int(key.get()) == 0:
            ForceTuningLabels[key].configure(state="disabled")
        else:
            ForceTuningLabels[key].configure(state="normal")
    ModifIndique("General", True)
    
# Appelée en cas de modification
def cmdGalModif():
    #print("def cmdGalModif")
    ModifIndique("General", True)

def cmdRbtSavBank():
    RbtSavBankGreen()
    lachaine = w.LblCfgBankChoisi.cget("text")
    NoBank = Vsavbank.get()
    w.LblCfgBankChoisi.configure(text=lachaine[:17] + NoBank)

def cmdRbtSavCfg():
    RbtSavCfgGreen()

# Grise son label si valeur < 5
def cmdBindCh():      #Attribut command de SbxBindCh
    if int(w.SbxBindCh.get()) < 5:
        w.LblBindCh.configure(state="disabled")
    else:
        w.LblBindCh.configure(state="normal")
    ModifIndique("General", True)

def cmdRcmModif():
    ModifIndique("Rc model", True)

# Détecte un changement de transmitter 
def cmdVtx():
    global VtxMem, MinMaxAuto, DefaultMinMax
    if VtxMem <> Vtx.get():
        ModifIndique("General", True)
    if MinMaxAuto.get() == "1":
        Valorise(w.EnyMin100, DefaultMinMax[Vtx.get()][0])
        Valorise(w.EnyMax100, DefaultMinMax[Vtx.get()][1])

# Détecte un changement de SERIAL|PPM 
def cmdVsignal():
    global VsignalMem
    if VsignalMem <> Vsignal.get():
        ModifIndique("General", True)

# Détecte un changement Yes|No de telemetry
def cmdVtelemetry():
    global VtelemetryMem
    if VtelemetryMem <> Vtelemetry.get():
        ModifIndique("General", True)

# Détecte un changement d' autobind 
def cmdVautobind():
    global VautobindMem
    if VautobindMem <> Vautobind.get():
        ModifIndique("RC model", True)
        
# Détecte un changement de power
def cmdVpower():
    global VpowerMem
    if VpowerMem <> Vpower.get():
        ModifIndique("RC model", True)
    
#***************************************************************************

#*** Les Entry *************************************************************
# Limite le nb de car pour Brand
def EnyBrand_KeyRelease(p1):
    LimitLen(w.EnyBrand,10,"For Brand, max = 10 characters", True)
    CheckIfAuthorizedChar.CC(w.EnyBrand, "#c5d8d7")
    WidgetsValidation()
    ModifIndique("RC model", True)
def EnyBrand_Survol(p1):
    HelpInfo("Brand : the RC model builder (required)")

# Pour Brand et RC model
def EnyBrand_RC_model_Rclic(e):
    msg = \
"These 2 fields do not appear in Multiprotocol.ino.\n" + \
"Their roles is to clarify the links between parameters and RC models.\n\n" + \
"They are still required.\n" + \
"With them, it may be possible in the future to build a RC model database." + \
"@french@\
Ces 2 champs (zone de texte) n\'apparraissent dans Multiprotocol.ino.\n" + \
"Leur rôle est de clarifier les liens entre paramètres et modèles réduits.\n\n" + \
"Ils ont obligatoires.\n" + \
"Avec eux, il sera peut être possible dans le futur de construire une base \
de données de modèles réduits radiocommandés."
    DisplayAddInfo("Brand and RC model", msg, 6, "Top")   

# Les noms de configuration
def EnyCfg_KeyRelease(e):
    w.BtnSavConfig.configure(state="normal")
    w.BtnSavConfig2.configure(state="normal")
def EnyCfgX_Survol(e):
    HelpInfo("You can choose the alias for the backup directories here (optional)")    

# Limite le nb de car pour Chanels Order
def EnyChanelsOrder_KeyRelease(p1):
    sys.stdout.flush()
    LimitLen(w.EnyChanelsOrder,4,"For Chanels Order, max = 4 characters", True)
    CheckIfAuthorizedChar.CC(w.EnyChanelsOrder, "white")
    ModifIndique("General", True)    
def EnyChanelsOrder_Survol(p1):
    HelpInfo("Combination of 4 characters 'AETR'")
def EnyChanelsOrder_Rclic(p1):
    msg = "Modify the channel order based on your TX: AETR, TAER, RETA...\n" + \
"Examples: Flysky & DEVO is AETR, JR/Spektrum radio is TAER, Multiplex is AERT...\n" + \
"Default is AETR." + \
"@french@\
Pour adapter l'ordre des canaux à votre émetteur : AETR, TAER, RETA...\n" + \
"Exemples: pour Flysky et DEVO c'est AETR. Pour la radio JR/Spektrum c'est TAER. \
Pour Multiplex c'est AERT...\n" + \
"Par défaut : AETR."
    DisplayAddInfo("Channels order", msg, 4, "Bottom")
 
# Limite le nb de car pour Chanels Reverse
def EnyChanelsReverse_KeyRelease(p1):
    sys.stdout.flush()
    LimitLen(w.EnyChanelsReverse,4,"For Chanels Reverse, max = 4 characters", True)
    CheckIfAuthorizedChar.CC(w.EnyChanelsReverse, "white")
    ModifIndique("General", True)    
def EnyChanelsReverse_Survol(p1):
    HelpInfo("Transmitter inversions with the characters 'AETR'")
def EnyChanelsReverse_Rclic(p1):
    msg = "To reverse the direction of the specified channel for all protocols.\n" + \
"Examples: Flysky & DEVO is AETR, JR/Spektrum radio is TAER, Multiplex is AERT...\n" + \
"Default is AETR." + \
"@french@\
Pour inverser le sens d'une commande (d'un canal). Agit sur tous les protocoles.\n" + \
"Exemples: pour Flysky et DEVO c'est AETR. Pour la radio JR/Spektrum radio \
c'est TAER. Pour Multiplex c'est AERT...\n" + \
"Par défaut : AETR."
    DisplayAddInfo("Channels reverse", msg, 4, "Bottom")
    
# Configurator
def EnyConfigurateur_KeyRelease(p1):
    ModifIndique("RC model", True)
def EnyConfigurateur_Survol(p1):
    HelpInfo("Configurator : your name if you are creating a RC model (optional)")

# EnyCyrfId
def EnyCyrfId_KeyRelease(e):
    CheckIfAuthorizedChar.CC(w.EnyCyrfId, "white")
    ModifIndique("General", True)
def EnyCyrfId_Survol(e):
    HelpInfo("[CYRF ID] = corresponds to #define FORCE_CYRF_ID ID_value")
def EnyCyrfId_Rclic(e):
    msg = \
"FORCE_CYRF_ID	\"\\x12\\x34\\x56\\x78\\x9A\\xBC\"\n\n" + \
"Protocols using the CYRF6936 (DSM, Devo, Walkera...) are using the CYRF ID \
instead which should prevent duplicated IDs.\n" + \
"If you have 2 Multi modules which you want to share the same ID so you can \
use either to control the same RC model \
then you can force the ID to a certain known value using this.\n" + \
"Disabled by default, you should validate only for test purpose or if you \
know exactly what you are doing!!!\n" + \
"To validate it, enter a value.\n\
@french@\
FORCE_CYRF_ID	\"\\x12\\x34\\x56\\x78\\x9A\\xBC\"\n\n" + \
"Les protocoles liés au CYRF6936 (DSM, Devo, Walkera...) utilisent l'ID CYRF \
ce qui évite les ID en double.\n" + \
"Si vous souhaitez partager le même identifiant avec 2 modules Multi 4-en-1, \
vous pouvez utiliser le même pour contrôler votre modèle radiocommandé. \
Dans ce cas vous devez forcer l'ID à une valeur connue.\n" + \
"Validez le uniquement pour des tests ou si savez ce que vous faites.\n" + \
"Pour valider, entrez une valeur pour l\'ID"
    DisplayAddInfo("CYRF ID", msg, 8, "Bottom")
    
# Futur1
def EnyFutur1_KeyRelease(p1):
    ModifIndique("RC model", True)
def EnyFutur1_Survol(p1):
    HelpInfo("Futur1 : for future improvements of RC model parameter (not required)")

# EnyGlobalId
def EnyGlobalId_KeyRelease(e):
    CheckIfAuthorizedChar.CC(w.EnyGlobalId, "white")
    ModifIndique("General", True)
def EnyGlobalId_Survol(e):
    HelpInfo("[Global ID] = corresponds to #define FORCE_GLOBAL_ID ID_value") 
def EnyGlobalId_Rclic(e):
    msg = \
"FORCE_GLOBAL_ID 0x12345678\n\n" + \
"A global ID is used by most protocols to bind and retain the bind to models. \
To prevent duplicate IDs, it is automatically \
generated using a random 32 bits number the first time the eeprom is initialized.\n" + \
"If you have 2 Multi modules which you want to share the same ID so you can \
use either to control the same RC model \
then you can force the ID to a certain known value using the lines below.\n" + \
"Disabled by default, you should validate only for test purpose or if you \
know exactly what you are doing!!!\n" + \
"To validate it, enter a value.\n\
@french@\
FORCE_GLOBAL_ID 0x12345678\n\n" + \
"Un ID global est utilisé par la plupart des protocoles pour binder (lier) \
et conserver la liaison avec les modèles. \
Pour éviter les identifiants en double, il est automatiquement généré à l'aide \
d'un nombre aléatoire de 32 bits lors de la première initialisation de l'eeprom.\n" + \
"Si vous souhaitez partager le même ID avec 2 modules Multi 4-en-1 , vous pouvez \
utiliser le même pour votre modèle radiocommandé. Vous devez dans ce cas forcer \
l’ID à une valeur connue.\n" + \
"Validez le uniquement pour des tests ou si savez ce que vous faites.\n" + \
"Pour valider, entrez une valeur pour l\'ID"
    DisplayAddInfo("Global ID", msg, 9, "Bottom")

# Clic-D sur EnyMin100 ou EnyMax100
def EnyMinMax_Rclic(p1):
    msg = "To set the end points in microseconds.\n" + \
"A few things to consider:\n" + \
" - If you put too big values compared to your TX you won't be able to reach the \
extremes which is bad for throttle as an example\n" + \
" - If you put too low values you won't be able to use your full stick range, \
it will be maxed out before reaching the ends\n" + \
" - Centered stick value is usually 1500. It should match the middle between MIN \
and MAX, ie Center=(MAX+MIN)/2. If your TX is not centered you can adjust the \
value MIN or MAX.\n" + \
" - 100% is referred as the value when the TX is set to default with no trims\
@french@\
Pour règler les largeurs d'impulsions (en µsecondes) des émetteurs.\n" + \
"Quelques considérations :\n" + \
" - si vous choisissez une valeur trop importante comparée à celle de votre émetteur, \
vous ne profiterez pas de l'étendue totale pour commander les gaz par exemple\n" + \
" - si vous choisissez une valeur trop faible vous ne profiterez pas du débattement maximal \
des manettes ou volant\n" + \
" - la position \"milieu\" d'une commande correspond normalement à 1500 µsecondes. Si votre \
commande est excentrée, vous pouvez adapter les MIN et MAX.\n" + \
" - pour valoriser au mieux MIN et MAX pensez à neutraliser les trims"
    DisplayAddInfo("PPM_Min_100 and PPM_Max_100", msg, 9, "Bottom")

# EnyMin100 et EnyMax100 survolés
def EnyMinMax_Survol(p1):
    #sys.stdout.flush()
    HelpInfo("PPM_Min_100 : 800 to 1200 / PPM_Max_100 : 1800 to 2200 (required values)")

def EnyOthers_Survol(p1):
    HelpInfo("Others : for future improvements and|or for your annotations")

# Protocole et qsous-protocole.
#Note : appelle WidgetsValidation et ModifIndique
def EnyProtocol_SubProtocol_KeyRelease(p1):
    CheckIfAuthorizedChar.CC(w.EnyProtocol, "white")
    CheckIfAuthorizedChar.CC(w.EnySubProtocol, "white")
    WidgetsValidation()
    ModifIndique("RC model", True)
# EnyProtocol survolé
def EnyProtocol_Survol(p1):
    HelpInfo("Protocols : preferably use the list below for yor choice")
# EnySubProtocol survolé
def EnySubProtocol_Survol(p1):
    HelpInfo("Sub Prot.: preferably use the list below for yor sub protocol choice")
    
# Limite le nb de car pour Rc_Model
def EnyRcModel_KeyRelease(p1):
    sys.stdout.flush()
    LimitLen(w.EnyRcModel,20,"For RC model, max = 20 characters", True)
    CheckIfAuthorizedChar.CC(w.EnyRcModel, "#c5d8d7")
    WidgetsValidation()
    ModifIndique("RC model", True)
def EnyRcModel_Survol(p1):
    HelpInfo("RC model : the name of the RC model (required)")
#***************************************************************************

#*** Les labels ************************************************************
def LblNbItem_Survol(p1):
    HelpInfo("Maximal nb lines for RC model configuration list is 14")

# LblAddInfo survolé
def LblAddInfo_Survol(e):
    HelpInfo("Additional help : click on for hide")
#***************************************************************************

#*** Les listes ************************************************************
# Clic dans liste Rc model -> renseigne widgets pour afficher le paramétrage correspondant
def LbxChoisi_Lclic(p1):
    if w.LbxChoisi.size() == 0:                     #Sortir si aucune ligne
        return
    line=w.LbxChoisi.curselection()
    Valorise(w.EnyBrand, w.LbxChoisi.get(line)[1:11])
    Valorise(w.EnyRcModel, w.LbxChoisi.get(line)[12:32])

    #lachaine = w.LbxChoisi.get(line)    #intermédiaire lachaine inutile
    modele = w.LbxChoisi.get(line)
    #modele = lachaine
    DisplayRcModel(modele)
    WidgetsValidation()
    #HelpInfo("Selected line : " + modele)
def LbxChoisi_Survol(e):
    HelpInfo("RC model list : to select a parameterized RC model (see Option/Sorted List for RC models)")
#***************************************************************************

#*** Les messages **********************************************************
# Cacher Message1 si clic dessus
def Message1_Lclic(p1):
    w.Message1.place_forget()

# Cacher LbfAddInfo si clic dessus
def LbfAddInfo_Lclic(p1):
    w.LbfAddInfo.place_forget()
#***************************************************************************

#*** Les menus *************************************************************
# Si une valeur change dans un menu
def MnuChange():
    w.BtnSavConfig.configure(state="normal")
    w.BtnSavConfig2.configure(state="normal")

def MnuFileQuit():
    destroy_window()

def MnuFileSavMuiConfig():
    BtnSavConfig_Lclic(None)

def MnuHelpAbout():
    DisplayMsg('''MUI (Multiprotocol User Interface)''' + "\n" + Version + '\n' + \
    '''By R.J.''' + '\n' + '''Developed with Page (Donald Rozenberg)''' + "\n" + \
    "and with Python " + ('{0[0]}.{0[1]}'.format(sys.version_info)) + \
    " and Tkinter " + str(tk.TkVersion), \
    5)

def MnuHelpHelp():
    DisplayMsg( \
    "1) For the first use click on [Indicate] in order to inform MUI on the \
directory containing Multiprotocol.ino\n\n"
    "2) use the \'Gal:X | RC_model:X | Bank:X\' frame to choose a \
General configuration (for example with the [General] button of Cfg1)." + "\n\n" + \
    "3) set the \'General configuration\'." + "\n" \
"Choose Serial or PPM transmission with the [SERIAL] or [PPM] radiobutton and continue \
to set the general configuration. To validate click on [General] in \
the \'Save in CgfX BankX\' frame.\
\nFor Serial it's over, you can go to step 6. For PPM go to step 4." + "\n\n" \
    "4) use the list on the right to fill \'RC model configuration\' frame " +
    "and|or, directly fill this frame.\n" + \
    "In the \'RC model configuration\' frame, when a configuration is complete, \
click on [Add].\n\n" + \
    "5) when all configurations by Rc model are complete\n" + \
    "choose your Target (Cfg and Bank) and click on [RC_model] in the \
\'Save in CgfX BankX\' frame.\n\n" + \
    "6) to adapt and create _Config.h and _MyConfig.h, click [Synthesize]\n\n" + \
    "For additional help, click-R on buttons, checkbuttons etc.."
    , 26)

#Les menus pour la langue
def MnuLangEnglish():
    global LangEnglish, LangFrench
    LangFrench.set("1")
    if LangEnglish.get() == "1":
        LangFrench.set("0")
    w.BtnSavConfig.configure(state="normal")
    w.BtnSavConfig2.configure(state="normal")
def MnuLangFrench():
    global LangEnglish, LangFrench
    LangEnglish.set("1")
    if LangFrench.get() == "1":
        LangEnglish.set("0")
    w.BtnSavConfig.configure(state="normal")
    w.BtnSavConfig2.configure(state="normal")

def MnuMpDir():
    BtnIndicDirMp_Lclic(None)
#***************************************************************************
    
#*** Les radiobutton *******************************************************
# Autobind
def RbtAutoBind_Rclic(p1):
    msg = \
"For protocols which does not require binding at each power up (like Flysky, \
FrSky...),\n" + \
"you might still want a bind to be initiated each time you power up the TX.\n" + \
"As an example, it's usefull for the WLTOYS F929/F939/F949/F959 (all using \
the Flysky protocol) \
which requires a bind at each power up.\n" + \
"It also enables the Bind from channel feature, allowing to execute a \
bind by toggling a designated channel." + \
"@french@\
Pour les protocoles qui ne nécessitent pas de binding (liaison) à chaque \
mise en marche (comme Flysky, FrSky...) " + \
"vous souhaitez peut-être toujours qu'une liaison soit initialisée chaque \
fois que vous allumez l'émetteur.\n" + \
"Par exemple l'Autobind est utile pour le WLTOYS F929 / F939 / F949 / F959 \
(tous utilisant le protocole Flysky).\n" + \
"L'Autobind peut aussi rendre actif le \"Bind from channel\" vous donnant la \
possibilité de réaliser une liaison en basculant vers un canal désigné."
    DisplayAddInfo("Autobind", msg, 6, "Top")
def RbtAutoBind_Survol(p1):
    HelpInfo("Autobind = choose Yes if the protocol requires an autobind. \
The NO value is most often used")


# RbtLoadBank
#  RbtLoadBankGreen
#   DisplayLoadedCfg : Adapter les textes de LbfGalConfig et LbfConfigChoix
def RbtLoadBank():  #aeff ?
    pass
def RbtLoadBank_Survol(p1):
    HelpInfo("Bank : you can fill up to 5 banks, each containing up to 14 \
RC models")
def RbtLoadBankGreen():
    w.RbtLoadBank1.configure(bg="light gray")
    w.RbtLoadBank2.configure(bg="light gray")
    w.RbtLoadBank3.configure(bg="light gray")
    w.RbtLoadBank4.configure(bg="light gray")
    w.RbtLoadBank5.configure(bg="light gray")
    if Vloadbank.get() == "1":
        #DisplayLoadedCfg("Radiobutton", w.RbtLoadBank1)
        w.RbtLoadBank1.configure(bg="light green")
    if Vloadbank.get() == "2":
        #DisplayLoadedCfg("Radiobutton", w.RbtLoadBank2)
        w.RbtLoadBank2.configure(bg="light green")
    if Vloadbank.get() == "3":
        #DisplayLoadedCfg("Radiobutton", w.RbtLoadBank3)
        w.RbtLoadBank3.configure(bg="light green")
    if Vloadbank.get() == "4":
        #DisplayLoadedCfg("Radiobutton", w.RbtLoadBank4)
        w.RbtLoadBank4.configure(bg="light green")
    if Vloadbank.get() == "5":
        #DisplayLoadedCfg("Radiobutton", w.RbtLoadBank5)
        w.RbtLoadBank5.configure(bg="light green")


# P_HIGH et P_LOW
def RbtPower_Rclic(e):
    msg = \
"Power P_HIGH or P_LOW : high or low power setting for the transmission.\n" + \
"For indoor P_LOW is more than enough.\n\n" + \
"No effect if the corresponding LowPow of RF_Component is invalidated." + \
"@french@\
Haute et basse puissance : choix de la puissance d'émission.\n" + \
"En salle P_LOW est plus que suffisant.\n\n" + \
"Sans effet si LowPow du RF_Component correspondant n'est pas sélectionné."
    DisplayAddInfo("P_HIGH | P_LOW", msg, 6, "Top")

# P_LOW survolé
def RbtPowerLow_Survol(p1):
    HelpInfo("[P_LOW] = activated if corresponding [LowPow] of RF_Component is enabled")

# Si clic sur Telemetry Yes-No, invalide-Valide les boutons du protocole télémétrie
def RbtTelemetryNo_Lclic(p1):
    AllSerialProtocols("disabled", 99)
    AllSerialTypeProtocole("disabled")
def RbtTelemetryYes_Lclic(p1):
    AllSerialProtocols("normal", 99)
    AllSerialTypeProtocole("normal")
def RbtTelemetry_Rclic(p1):
    msg = \
"If you do not plan using the telemetry, click on \"No\"." + \
"@french@\
Si vous ne désirez pas utiliser la télémétrie, cliquer sur \"No\"."
    DisplayAddInfo("Telemetry Yes or No", msg, 2, "Bottom")

def RbtSavBankX_Survol(e):
    HelpInfo("Bank (in \"Save in CfgX BankX\") = the bank that will host \
the RC model parameters displayed")

def RbtSavCfg_Survol(p1):
    HelpInfo("Cfg : choose here the backup directory (Cfg1, Cfg2, Cfg3 : \
3 PPM directory for 3 different transmitters)")

# Si clic SERIAL ou PPM Invalide-Valide tous les EnyMin100 etc ..
def RbtSignalSerial_Lclic(p1):
    AllPpmParameters("disabled")
    AllTransmittersState("disabled")
def RbtSignalPPM_Lclic(p1):
    sys.stdout.flush()
    AllPpmParameters("normal")
    AllTransmittersState("normal")
def RbtSignalSerial_PPM_Rclic(e):
    msg = \
"Serial :\n" + \
"The serial mode enables full editing of all the parameters in the GUI of \
the radio.\nIt is enabled by placing the rotary switch on position 0.\n" + \
"This is available natively for ER9X, ERSKY9X and OpenTX.\n\n" + \
"PPM:\n" + \
"You can configure all details about PPM.\n" + \
"If you do not plan to use the PPM mode, you save Flash space." + \
"@french@\
Serial (transmission des données en série):\n" + \
"Le mode série permet l'édition complète de tous les paramètres avec \
l'interface graphique de la radio.\nPour ce mode, placer le codeur \
rotatif en position \"0\".\n" + \
"A l'origine ce mode est prévu pour ER9X, ERSKY9X and OpenTX.\n\n" + \
"PPM (proportional pulse modulated):\n" + \
"Vous pouvez configurer tous ce qui est nécessaire à ce mode.\n" + \
"Si vous ne désirez pas utiliser le mode PPM vous gagnez de l'espace en \
mémoire Flash."
    DisplayAddInfo("Serial | PPM", msg, 9, "Bottom")
    
# Couleur verte pour le RbtSavCfg sélectionné
def RbtSavCfgGreen():
    w.RbtSavCfg1.configure(bg="light gray")
    w.RbtSavCfg2.configure(bg="light gray")
    w.RbtSavCfg3.configure(bg="light gray")
    if Vsavcfg.get() == "1":
        w.RbtSavCfg1.configure(bg="light green")
    if Vsavcfg.get() == "2":
        w.RbtSavCfg2.configure(bg="light green")
    if Vsavcfg.get() == "3":
        w.RbtSavCfg3.configure(bg="light green")

def RbtSavBankGreen():
    w.RbtSavBank1.configure(bg="light gray")
    w.RbtSavBank2.configure(bg="light gray")
    w.RbtSavBank3.configure(bg="light gray")
    w.RbtSavBank4.configure(bg="light gray")
    w.RbtSavBank5.configure(bg="light gray")
    if Vsavbank.get() == "1":
        w.RbtSavBank1.configure(bg="light green")
    if Vsavbank.get() == "2":
        w.RbtSavBank2.configure(bg="light green")
    if Vsavbank.get() == "3":
        w.RbtSavBank3.configure(bg="light green")
    if Vsavbank.get() == "4":
        w.RbtSavBank4.configure(bg="light green")
    if Vsavbank.get() == "5":
        w.RbtSavBank5.configure(bg="light green")

# Les transmitters
def RbtTx_Rclic(e):
    msg = \
"It is important for the module to know the endpoints of your radio.\n" + \
"In thid frame, there are some standard transmitters already preconfigured.\n" + \
"Validate the one which matches your transmitter.\n\n" + \
"TX END POINTS :\n" + \
"ER9X/ERSKY9X/OpenTX\t(988<->2012 microseconds)\n" + \
"DEVO\t\t\t(1120<->1920 microseconds)\n" + \
"Spektrum\t\t\t(1100<->1900 microseconds)\n" + \
"HISKY\t\t\t(1120<->1920 microseconds)\n" + \
"Multiplex MC2020\t\t(1250<->1950 microseconds)\n" + \
"Walkera PL0811-01H\t(1000<->1800 microseconds)\n" + \
"Custom, normaly\t\t(1100<->1900 microseconds)" + \
"@french@\
Il est important pour le module 4-en-1 de connaître les min. et max. des \
durées d'impulsions de votre radio.\n" + \
"Il existe ici, des préconfigurations pour les émetteurs standard.\n" + \
"Validez celle qui correspond à votre émetteur.\n\n" + \
"TX END POINTS (durées min. et max. d'impulsions):\n" + \
"ER9X/ERSKY9X/OpenTX\t(988<->2012 microseconds)\n" + \
"DEVO\t\t\t(1120<->1920 microseconds)\n" + \
"Spektrum\t\t\t(1100<->1900 microseconds)\n" + \
"HISKY\t\t\t(1120<->1920 microseconds)\n" + \
"Multiplex MC2020\t\t(1250<->1950 microseconds)\n" + \
"Walkera PL0811-01H\t(1000<->1800 microseconds)\n" + \
"Custom, normaly\t\t(1100<->1900 microseconds)"
    DisplayAddInfo("Transmitters", msg, 13, "Bottom")
def RbtTx_Survol(e):
    HelpInfo("The transmitters : for an automatic valuation, \
check \"Option / PPM_Min_Max_Auto (according to ..)\"")
#***************************************************************************

#*** Les spinbox ***********************************************************
# AFHDS2A_LQI
def SbxAfhds2aLqi_Key(p1):
    #print("def SbxAfhds2aLqi_Key")
    ModifIndique("General", True)
def SbxAfhds2aLqi_Survol(p1):
    #print ("def SbxAfhds2aLqi_Survol")
    HelpInfo("VAFHDS2A_LQI : validated if greater than 4")
def SbxAfhds2aLqi_Rclic(p1):
    msg = \
"AFHDS2A specific settings\n\n" + \
"When enabled, the setting makes LQI (Link Quality Indicator) available on \
one of the RX ouput channel (5-14)." + \
"@french@\
Lorsqu'il est validé, le LQI (Link Quality Indicator) est disponible sur \
l'un des canaux de sortie du récepteur (de 5 à 14)."
    DisplayAddInfo("AFHDS2A_LQI", msg, 4, "Bottom")
    
# BIND_CH
def SbxBindCh_Key(p1):
    ModifIndique("General", True)
def SbxBindCh_Survol(p1):
    HelpInfo("Bind_Ch : enabled if value greater than 5")
def SbxBindCh_Rclic(p1):
    msg = \
"Also referred as Bind on powerup.\n" + \
"Bind from channel enables you to bind when a specified channel is going \
from low to high. This feature is only active \
if you specify AUTOBIND in PPM mode or set AutoBind to YES for serial \
mode. It also requires that the throttle channel is low." + \
"@french@\
Egalement appelé \"Bind on powerup\".\n" + \
"Le bind (lien émetteur-récepteur) se fait via un canal spécifié passant du \
niveau bas au niveau haut. Pour que ce soit actif, il faut spécifier \
Autobind en mode PPM ou initialiser Autobind avec Yes en mode Serial. \
Il est aussi nécessaire que le throttle (gaz) soit au niveau bas."
    DisplayAddInfo("Bind_Ch", msg, 5, "Bottom")

# DSM_THROTTLE_KILL_CH 15
def SbxDSM_THROTTLE_KILL_Rclic(e):
    msg = \
"Some models (X-Vert, Blade 230S...) require a special value to instant \
stop the motor(s).\n" + \
"You have to specify which channel (15 by default) will be used to kill \
the throttle channel.\n" + \
"If the channel 15 is above -50% the throttle is untouched but if it is \
between -50% and -100%, the throttle output will be forced between -100% \
and -150%.\n" + \
"For example, a value of -80% applied on channel 15 will instantly kill \
the motors on the X-Vert.\n\n" + \
"Choose the value 0 for disabling DSM_THROTTLE_KILL_CH" + \
"@french@\
Certains modèles (X-Vert, Blade 230S ...) nécessitent une valeur spéciale \
pour arrêter instantanément le(s) moteur(s).\n" + \
"Vous devez spécifier le canal (15 par défaut) qui sera utilisé pour annihiler \
le canal throttle (gaz).\n" + \
"Si le canal choisi est supérieur à -50%, le throttle n’est pas touché mais si \
il est compris entre -100% et -50%, le throttle sera forcé entre -150% \
et -100%.\n" + \
"Par exemple, une valeur de -80% appliquée sur le canal 15 tuera \
instantanément les moteurs du X-Vert.\n\n" + \
"Choisissez la valeur 0 pour invalider  DSM_THROTTLE_KILL_CH"
    DisplayAddInfo("DSM_THROTTLE_KILL_CH", msg, 8, "Bottom")
def SbxDSM_THROTTLE_KILL_Survol(e):
    HelpInfo("DSM_THROTTLE_KILL_CH : value 0 for disabled")
    
# FailSafe
def SbxFailSafe_Key(p1):
    ModifIndique("General", True)
def SbxFailSafe_Survol(p1):
    HelpInfo("FailSafe (THROTTLE_LOW) : force #define FAILSAFE_THROTTLE_LOW \
if value <> 0")
def SbxFailSafe_Rclic(p1):
    msg = \
"Failsafe throttle low value in percentage.\n" + \
"Value between -125% and +125%. Default -100.\n\n" + \
"The module is using the same default failsafe values for all protocols \
which currently supports it:\n" + \
"Devo, WK2x01, SFHSS, HISKY/HK310 and AFHDS2A\n" + \
"All channels are centered except throttle which is forced low.\n" + \
"If you want to disable \"FAILSAFE_THROTTLE_LOW\", choose a \"0\" value" + \
"@french@\
Valeur basse du Failsafe (mise en sécurité) en %.\n" + \
"La gamme de valeurs possibles va de -125% à +125%. Par défaut -100%.\n\n" + \
"Le module utilise la même valeur par défaut pour tous les protocoles qui \
le supportent actuellement :\n" + \
"Devo, WK2x01, SFHSS, HISKY/HK310 and AFHDS2A\n" + \
"Avec le Failsafe, tous les canaux sont centrés sauf celui du throttle (gaz) \
qui est forcé au minimum par défaut ou à la valeur du \"FAILSAFE_THROTTLE_LOW\".\n" + \
"Pour invalider le \"FAILSAFE_THROTTLE_LOW\", choisissez la valeur \"0\"."
    DisplayAddInfo("FailSafe (throttle low)", msg, 9, "Bottom")

# Min Ppm Channels
def SbxMinPpmChannels_Rclic(e):
    msg = \
"Minimal number of PPM Channels\n\n" + \
"Used to set the minimum number of channels which the module should \
receive to consider a PPM frame valid.\n" + \
"The default value is 4 to receive at least AETR for flying models but \
you could also connect the PPM from a car radio which has only 3 channels \
by changing this number to 3."+ \
"@french@\
Nombre minimal de canaux PPM\n\n" + \
"C'est le nombre minimal de canaux que traitera le module. Cette valeur \
prend en compte une trame PPM valide.\n" + \
"La valeur par défaut est 4 afin de traiter au minimum AETR mais vous avez bien \
sûr la possibilité d'utiliser seulement 2 ou 3 canaux avec une voiture \
radiocommandée. Dans ce cas vous pouvez passer cette valeur à 2 ou 3."
    DisplayAddInfo("MinNbChannels", msg, 6, "Bottom")

# Max PPM Chennels
def SbxMaxPpmChannels_Rclic(e):
    msg = \
"Maximal number of PPM Channels\n\n" + \
"Used to set the maximum number of channels which the module should work with. \
Any channels received above this number are discarded.\n" + \
"The default value is 16 to receive all possible channels but you might \
want to filter some \"bad\" channels from the PPM frame like the ones above \
6 on the Walkera PL0811."+ \
"@french@\
Nombre maximal de canaux PPM\n\n" + \
"C'est le nombre maximal de canaux que traitera le module. Tout canal dont \
le numéro est supérieur à cette valeur sera rejeté.\n" + \
"La valeur par défaut est 16 pour tout traiter mais vous pouvez proscrire \
certains canaux génants comme ceux supérieurs à 6 de la radio Walkera PL0811."
    DisplayAddInfo("MinNbChannels", msg, 7, "Bottom")
    
# Le nb de bank survolé
def SbxNbBanks_Survol(p1):
    HelpInfo("Nb_banks : for PPM only. minimum=1 maximum=5")
def SbxNbBanks_Rclic(e):
    msg = \
"This parameter indicates the number of desired banks between 1 and 5. Default \
is 5.\n" + \
"The banks are defined in the \"Rc model configuration\" frame and in the list \
on the right\n" + \
"A system of banks enable the access to more protocols than positions on the \
rotary switch.\n\n" +\
"Banks can be selected by placing the rotary switch on position 15, power up \
the module and \
short press the bind button multiple times until you reach the desired one.\n" + \
"The bank number currently selected is indicated by the number of LED flash.\n" + \
"You can associate multiple times the same protocol to different rotary switch positions to \
take advantage of the model match based on RX_Num.\
@french@\
Ce parametre indique le nombre de \"bank\". Il est compris entre 1 et 5. \
Par defaut : 5.\n" + \
"Les \"banks\" sont definies dans le cadre \"Rc model configuration\" et dans la \
liste en bas a droite\n" + \
"Le principe des \"banks\" procure l'accès a plus de protocoles que n'en permet le \
codeur rotatif.\n\n" +\
"Les \"banks\" sont sélectionnees en plaçant le codeur rotatif en position 15 a \
la mise en marche de l'émetteur et \
en appuyant brièvement sur le bouton Bind d'un nombre de fois égal au No de \"bank\" choisi.\n" + \
"La LED rouge clignote alors autant de fois que le No choisi.\n" + \
"Vous pouvez associer plusieurs fois le même protocole à différentes positions du \
codeur rotatif en utilisant la spécificité du RX_num."
    DisplayAddInfo("Nb_banks", msg, 10, "Bottom")

# Option
def SbxOption_Rclic(e):
    msg = \
"The value is between -128 and +127.\n" + \
"The option value is only valid for some protocols, read this page for more \
information:\n" + \
"https://github.com/pascallanger/DIY-Multiprotocol-TX-Module/blob/master/Prot\
ocols_Details.md\
@french@\
Valeur comprise entre -128 et +127.\n" + \
"Cette valeur est réservée pour quelques protocoles, lisez cette page pour vous \
informer:\n" + \
"https://github.com/pascallanger/DIY-Multiprotocol-TX-Module/blob/master/Prot\
ocols_Details.md"
    DisplayAddInfo("Option", msg, 4, "Top")
def SbxOption_Survol(e):
    HelpInfo("Option : valid only for some protocols (-128 < value < +127")
    
# Rx_num survolé
def SbxRxNum_Survol(p1):
    HelpInfo("Rx_num : using different RX_Num values for each \
RX will prevent starting a model with the false config")
def SbxRxNum_Rclic(e):
    msg = \
"RX_Num is used for TX & RX match. Using different RX_Num values for each \
receiver will prevent starting a model with the false config loaded...\n" + \
"RX_Num value is between 0 and 15.\
@french@\
Pour la correspondance émetteur-récepteur. Des valeurs différentes pour chaque \
récepteur empecheront de démarrer un modele avec une configuration érronée.\n" + \
"La valeur est comprise entre 0 et 15."
    DisplayAddInfo("RX_num", msg, 4, "Top")
    
# Force tuning
def ForceTuning_Survol(p1):
    HelpInfo("Force tuning choices : enabled if value <> 0")
def ForceTuningCC2055_Rclic(p1):
    msg = \
"CC2500 Fine Frequency Tuning\n\n" + \
"For optimal performance the CC2500 RF module used by the FrSkyD, FrSkyV, \
FrSkyX, SFHSS, CORONA and Hitec protocols needs\n" + \
"to be tuned for each protocol.\n" + \
"Initial tuning should be done via the radio menu with a genuine \
FrSky/Futaba/CORONA/Hitec receiver.\n" + \
"Once a good tuning value is found it can be set here and will override the \
radio's \'option\' setting for all existing and new models which use that protocol.\n" + \
"For more information: https://github.com/pascallanger/DIY-Multiprotocol-TX-Module/\n" +  \
"tree/master/docs/Frequency_Tuning.md\n\n" + \
"To validate set an appropriate value (replace the \"0\") to enable. Valid \
range is -127 to +127.\
@french@\
CC2500 Fine Frequency Tuning (ajustement de l'horloge interne)\n\n" + \
"Pour une performance maximale, un récepteur contenant un module CC2500 lié aux \
protocoles FrSkyD, FrSkyV, FrSkyX, SFHSS, CORONA et Hitec a besoin d'etre ajuste \
pour chaque protocole.\n" + \
"L'ajustage initial doit être fait par le menu de l'émetteur pour des récepteurs \
FrSky/Futaba/CORONA/Hitec.\n" + \
"Lorsqu'une bonne valeur est trouvée, elle peut être indiquée ce qui remplacera \
celle de lémetteur.\n" + \
"Pour plus d'informations : https://github.com/pascallanger/DIY-Multiprotocol-TX-Module/\n" + \
"tree/master/docs/Frequency_Tuning.md\n\n" + \
"Validez et ajustez en choisissant une valeur différente de 0 (de -127 à +127)."
    DisplayAddInfo("Force tuning", msg, 12, "Bottom")
    
def ForceTuningA7105(p1):
    msg = \
"A7105 Fine Frequency Tuning\n\n" + \
"Once a good tuning value is found it can be set here and will override the frequency \
tuning for a specific protocol.\n" + \
"To validate set an appropriate value (replace the \"0\") to enable. Valid range \
is -300 to +300 and default is 0.\
@french@\
A7105 Fine Frequency Tuning (ajustement de l'horloge interne)\n\n" + \
"Lorsqu'une bonne valeur est trouvée, elle peut être indiquée ce qui remplacera \
la valeur pour le protocole spécifié.\n" + \
"Validez et ajustez en choisissant une valeur différente de 0 (de -300 à +300). \
La valeur par défaut est 0."
    DisplayAddInfo("Force tuning", msg, 5, "Bottom")    
#***************************************************************************

#en cour : 
#A la fin dimensionner Message1 et placer en fin de .TCL (Cute et Paste)
#Menu pour changer français - anglais : créer MUI_english.py NON, il faut
# modifier DisplayAddInfo et HelpInfo. Pour cela utiliser les lambda ?
#Faire recap des fonctions utilisées


# Renseigne une liste avec les valeurs choisies
def AddInList(nom_liste):
    modele = "*" + w.EnyBrand.get().ljust(10," ") + "|" \
        + w.EnyRcModel.get().ljust(20," ") + "[PROTOCOL=" + \
        w.EnyProtocol.get() + ",SUB_PROTOCOL=" + w.EnySubProtocol.get() + \
        ",RX_Num=" + w.SbxRxNum.get() + ",Power=" + Vpower.get() + \
        ",Auto_Bind=" + Vautobind.get() + ",Option=" + w.SbxOption.get() + \
        ",ConfiguratorName=" + w.EnyConfigurateur.get() + \
        ",FUTUR1=" + w.EnyFutur1.get() + "]"
    nom_liste.insert("end", modele)    
    WidgetsValidation()


# Valide-Invalide ce qui est relatif à PPM
def AllPpmParameters(etat):
    w.EnyMin100.configure(state=etat)
    w.EnyMax100.configure(state=etat)
    w.SbxMinPpmChannels.configure(state=etat)
    w.SbxMaxPpmChannels.configure(state=etat)
    w.SbxNbBanks.configure(state=etat)
    inverse_etat = "disabled"
    if etat == "disabled":
        inverse_etat = "normal"
    w.ChkFailSaveSerialOnly.configure(state=inverse_etat)


# Les Chk.. des protocoles télémétrie : state et value
# Note : si valeur=99 les valeurs ne sont pas modifiées
def AllSerialProtocols(etat, valeur):
    w.ChkAFHDS2A_FW.configure(state=etat)
    w.ChkBAYANG_HUB.configure(state=etat)
    w.ChkCABELL_HUB.configure(state=etat)
    w.ChkHITEC_FW.configure(state=etat)
    w.ChkHUB.configure(state=etat)
    w.ChkNCC1701_HUB.configure(state=etat)
    w.ChkFUTUR1.configure(state=etat)
    w.ChkAFHDS2A_HUB.configure(state=etat)
    w.ChkBUGS_HUB.configure(state=etat)
    w.ChkDSM.configure(state=etat)
    w.ChkHITEC_HUB.configure(state=etat)
    w.ChkHUBSAN_HUB.configure(state=etat)
    w.ChkSPORT.configure(state=etat)
    w.ChkFUTUR2.configure(state=etat)
    if valeur <> 99:
        che50.set(valeur)
        che51.set(valeur)
        che52.set(valeur)
        che53.set(valeur)
        che54.set(valeur)
        che55.set(valeur)
        che56.set(valeur)
        che57.set(valeur)
        che58.set(valeur)
        che59.set(valeur)
        che60.set(valeur)
        che61.set(valeur)
        che62.set(valeur)
        che63.set(valeur)


#Pour INVERT, MULTI_TELEMETRY, MULTI_STATUS
def AllSerialTypeProtocole(etat):
    w.ChkINVERT_TELEMETRY.configure(state=etat)
    w.ChkMULTI_TELEMETRY.configure(state=etat)
    w.ChkMULTI_STATUS.configure(state=etat)
    w.ChkSportPolling.configure(state=etat)


#Si SERIAL pas de transmitter (donc grisé)
def AllTransmittersState(etat):
    w.RbtCUSTOM.configure(state=etat)
    w.RbtDEVO7.configure(state=etat)
    w.RbtER9X.configure(state=etat)
    w.RbtHISKY.configure(state=etat)
    w.RbtSPEKTRUM.configure(state=etat)
    w.RbtTX_MPX.configure(state=etat)
    w.RbtWALKERA.configure(state=etat)
    w.RbtTXFUTUR1.configure(state=etat)


#Affiche le message concernant une erreur et emet un bip
def BadActionInfo(message):
    w.LblBadActionInfo2.configure(text=message)
    print ("\a")
    sys.stdout.flush()
        
# Vérifie l'ordre des canaux et retourne False si erreur
def ChanelsOrderVerify():
    tmp=w.EnyChanelsOrder.get()
    Valorise(w.EnyChanelsOrder, tmp.upper())
    trouve = False
    for item in TtChOrder:
        if item == w.EnyChanelsOrder.get():
            trouve = True
            break
    if trouve == False:
        BadActionInfo("Chanels/Order error")
    return trouve


# Vérifie Chanels/Reverse et corrige si nécessaire
def ChanelsReverseVerifyAndCorrect():
    tmp=w.EnyChanelsReverse.get()
    Valorise(w.EnyChanelsReverse, tmp.upper()) 
    reverse = ""
    trouve = True
    if len(w.EnyChanelsReverse.get()) > 0:
        GoodCh = "AETR"
        for char in w.EnyChanelsReverse.get():
            if GoodCh.find(char) > -1:
                reverse = reverse + char
            else:
                trouve = False
    if trouve == False:
        BadActionInfo("Chanels/Reverse corrected error")
    Valorise(w.EnyChanelsReverse, ReverseCorrige(reverse))    


# Teste si un caractère interdit est saisi dans un Entry qui prend la
# couleur rouge si le caractère est interdit
""" def CheckIfAuthorizedChar(LaEntry, NormalColor):
    if len(LaEntry.get()) == 0:
        LaEntry.configure(background=NormalColor)
        return True
    #"u" pour convertir en unicode
    interdits = u"=[],àäéèêëîïôöûüÿ\"\'\\"  
    CorrectChar = True
    for char in LaEntry.get():
        P = interdits.find(char)
        if P > -1:
            CorrectChar = False
    if CorrectChar == True:
        LaEntry.configure(background=NormalColor)
    else:
        LaEntry.configure(background="red")
        BadActionInfo("Don't use [ ] , \" \' \\ and special characters")
    return CorrectChar """


# Positionne un Checkbox
#Note : positionne che_variable(du Checkbox) en cherchant search 
#dans srcchaine(mise en majuscule)
""" def ChkPositionne(srcchaine, search, che_variable):
    che_variable.set(0)
    if srcchaine.upper().find(search) > -1:
        che_variable.set("1") """


# Mise à blanc des textes et valeurs par défaut des widgets
#Note : cette fonction pourrait être considérée inutile,
#mais je la conserve car elle rend ce programme plus explicite.
def Default_Values():
    #print("def Default_Values")
    global VtxMem, VsignalMem, VtelemetryMem, VautobindMem, VpowerMem
#SERIAL ou PPM positionné sur PPM
    Vsignal.set("PPM")
    VsignalMem = "PPM"
#Channels, Order et Reverse
    w.EnyChanelsOrder.delete(0,"end")
    w.EnyChanelsReverse.delete(0,"end")
#Pas de télémétrie par défaut
    Vtelemetry.set("NO")
    VtelemetryMem = "NO"
#Protocole télémétrie par défaut
    #Vtelprot.set("NONE")    #RPT tt les Chkxx mis à "1"
#Protocoles télémétrie. Tous validés par défaut
    AllSerialProtocols("normal", "1")
#Options télémétrie (INVERT, Multi_Telemetry, Multi_Status)
    che42.set("1")
    che43.set("0")
    che44.set("0")  
#Le nombre de Bank par défaut
    Valorise(w.SbxNbBanks,"1")
#Aucun RF_Component et leurs LowPower par défaut
    che74.set("0")              #Les RF_Components
    che75.set("0")
    che76.set("0")
    che77.set("0")
    che20.set("0")              #Les LowPower
    che21.set("0")
    che22.set("0")
    che23.set("0")
#Les transmitters
    Vtx.set("CUSTOM")
    VtxMem = "CUSTOM"
#RX_num
    #Vrxnum.set("0")
    Valorise(w.SbxRxNum, "0")
#Les Power , AutoBind , Option
    Vpower.set("P_HIGH")
    VpowerMem = "P_HIGH"
    Vautobind.set("NO")
    VautobindMem = "NO"
    Valorise(w.SbxOption, "0")
#Les paramètres PPM
    Valorise(w.EnyMin100, "1100")
    Valorise(w.EnyMax100, "1900")
    Valorise(w.SbxMinPpmChannels, "4")
    Valorise(w.SbxMaxPpmChannels, "16")
#Les Entry    
    w.EnyBrand.delete(0,"end")
    w.EnyRcModel.delete(0,"end")
    w.EnyProtocol.delete(0,"end")
    w.EnySubProtocol.delete(0,"end")
    w.EnyConfigurateur.delete(0,"end")
    w.EnyOthers.delete(0,"end")         #Pour Others
#checkbutton FailSafe (ancien STM32)
    che45.set("0")
#Wait for bind
    che31.set("1")
#Orange blue
    che32.set("0")
#Sport_Polling, Chk_Boot_Loader
    che46.set("0")
    che49.set("1")
#Global_ID et Cyrf_ID
    Valorise(w.EnyGlobalId, "")
    Valorise(w.EnyCyrfId, "")
#USE_A7105_CH15_TUNING
    che24.set("1")
#DSM max throw
    w.ChkDSM_MAX_THROW.configure(state="normal")
    che30.set("0")
#DSM_THROTTLE_KILL_CH
    Valorise(w.SbxDSM_THROTTLE_KILL,"15")
#BIND_CH
    Valorise(w.SbxBindCh, "16")
#Les spinbox de Force tuning
    for key in ForceTuningLabels.keys():
        Valorise(key, "0")
#Valeur du FailSafe
    che10.set("0")
    Valorise(w.SbxFailSafe, "-100")
#Valeur de AFHDS2A_LQI
    Valorise(w.SbxAfhds2aLqi, "14")
#La liste des configuratiions de modèles RC
    w.LbxChoisi.delete(0, "end")
#Lesradiobutton de Save ..
    Vsavcfg.set("1")
    Vsavbank.set("1")
#Les boutons de fonctionnement
    w.BtnDel.configure(state="disabled")
#Allumer les LEDs de Cfg1
    LedOnOff(w.LblCfg1Gal, "General")
    LedOnOff(w.LblCfg1RcModel, "RcModel")


# Supprime la ligne sélectionnée de LbxChoisi
def DelInList(nom_liste):
    try:
        w.LbxChoisi.delete(w.LbxChoisi.curselection())
    except:
        BadActionInfo("No possible [Del RC model >]")
    WidgetsValidation()


# Fermer la fenêtre et quitter le programme
def destroy_window():
    global GalModif, RcmModif  
    destruct = False
    if GalModif or RcmModif:
        print("\a")
        if tkMessageBox.askyesno("Quit", "Leave this program ?"):
            destruct = True
    else:
        destruct = True
    if destruct:
        global top_level
        top_level.destroy()
        top_level = None
        

# Affiche une aide supplémentaire à l'aide de LbfAddInfo+LblAddInfo
#Note : height=175 correspond à 8 lignes de texte
def DisplayAddInfo(Titre, Msg, NbLine, Pos):
    global LangFrench
    ley = 330
    if Pos == "Top":
        ley = 50
    h = 14 * NbLine
    w.LblAddInfo.place(height = h)
    w.LbfAddInfo.place(x=70, y=ley, height=h+23, width=760)
    w.LbfAddInfo.configure(text = Titre)
    i = Msg.find("@french@")
    if i > -1:
        if LangFrench.get() == "1":
            #print i
            Msg = Msg[i+8:]
        else:
            Msg = Msg[:i]
    w.LblAddInfo.configure(text = Msg)
    
   
# Renseigne les widget pour la configuration générale
def DisplayGeneral(LeModele):
    #print("def DisplayGeneral")
#L'ordre des canaux émis
    ChOrder="AETR"
    if LeModele.find("Order_Channel=") <> -1:
        result=StrExtract.SE(LeModele, "Order_Channel=", ",", "AETR").upper()
        for item in TtChOrder:
            if item == result:
                ChOrder=result
    Valorise(w.EnyChanelsOrder, ChOrder)
#Les reverse
    reverse =""
    if LeModele.find("REVERSE=") > -1:
        result=StrExtract.SE(LeModele, "REVERSE=", ",", "").upper()
        if len(result) > 0:
            GoodCh = "AETR"
            for char in result:
                if GoodCh.find(char) > -1:
                    reverse = reverse + char
    Valorise(w.EnyChanelsReverse, ReverseCorrige(reverse))
#Renseigner les Min100 etc..
    AllPpmParameters("normal")                 #Valider les widgets Entry
    result="1100"
    if LeModele.find("MIN_100=") > -1:
        result=StrExtract.SE(LeModele, "MIN_100=", ",", "1100")
    Valorise(w.EnyMin100, result)
    result="1900"
    if LeModele.find("MAX_100=") > -1:
        result=StrExtract.SE(LeModele, "MAX_100=", ",", "1900")
    Valorise(w.EnyMax100, result)
    result="4"
    if LeModele.find("MIN_PPM_CHANNELS=") > -1:
        result=StrExtract.SE(LeModele, "MIN_PPM_CHANNELS=", ",", "4")
    Valorise(w.SbxMinPpmChannels, result)
    result="16"
    if LeModele.find("MAX_PPM_CHANNELS=") > -1:
        result=StrExtract.SE(LeModele, "MAX_PPM_CHANNELS=", ",", "16")
    Valorise(w.SbxMaxPpmChannels, result)
#SERIAL ou PPM
    if LeModele.upper().find("SERIAL|PPM=SERIAL") > -1:
        Vsignal.set("SERIAL")                   #C'est SERIAL
        AllPpmParameters("disabled")           #Invalider les widgets Entry des PPM puisque c'est SERIAL qui est demandé
        AllTransmittersState("disabled")
    else:                                       #C'est PPM
        Vsignal.set("PPM")
        AllTransmittersState("normal")
#Tester si la télémétrie est demandée
    if LeModele.upper().find("TELEMETRY=YES") <> -1:
        Vtelemetry.set("YES")
        AllSerialProtocols("normal", "0")       #Chk.. mis à "1" si nécessaire ci-après
        AllSerialTypeProtocole("normal")
    else:
        Vtelemetry.set("NO")
        AllSerialProtocols("disabled", 99)
        AllSerialTypeProtocole("disabled")
#Les protocoles de la télémétrie
    ChkPositionne.CP(LeModele, "*AFHDS2A_FW", che50)
    ChkPositionne.CP(LeModele, "*BAYANG_HUB", che51)
    ChkPositionne.CP(LeModele, "*CABELL_HUB", che52)
    ChkPositionne.CP(LeModele, "*HITEC_FW", che53)
    ChkPositionne.CP(LeModele, "*HUB", che54)
    ChkPositionne.CP(LeModele, "*NCC1701_HUB", che55)
    ChkPositionne.CP(LeModele, "*FUTUR1", che56)
    ChkPositionne.CP(LeModele, "*AFHDS2A_HUB", che57)
    ChkPositionne.CP(LeModele, "*BUGS_HUB", che58)
    ChkPositionne.CP(LeModele, "*BUGS_HUB", che59)
    ChkPositionne.CP(LeModele, "*HITEC_HUB", che60)
    ChkPositionne.CP(LeModele, "*HUBSAN_HUB", che61)
    ChkPositionne.CP(LeModele, "*SPORT", che62)
    ChkPositionne.CP(LeModele, "*FUTUR2", che63)
#Télémétrie INVERT
    ChkPositionne.CP(LeModele, "TELEMETRY_INVERT=YES", che42)
#Télémétrie MULTI et STATUS
    ChkPositionne.CP(LeModele, "TELEMETRY_MULTI=YES", che43)
    ChkPositionne.CP(LeModele, "TELEMETRY_STATUS=YES", che44)   
#Positionner les RF_Components et leurs LowPower
    ChkPositionne.CP(LeModele, "*A7105", che74)
    ChkPositionne.CP(LeModele, "*CYRF6936", che75)   
    ChkPositionne.CP(LeModele, "*CC2500", che76)   
    ChkPositionne.CP(LeModele, "*NRF24L01", che77)   
    ChkPositionne.CP(LeModele, "-A7105", che20)        #Les LowPower
    ChkPositionne.CP(LeModele, "-CYRF6936", che21)   
    ChkPositionne.CP(LeModele, "-CC2500", che22)
    ChkPositionne.CP(LeModele, "-NRF24L01", che23)
#Positionner l'émetteur choisi (transmitter)
    result=("CUSTOM")
    if LeModele.find("Transmitter=") > -1:
        result=StrExtract.SE(LeModele, "Transmitter=", ",", "CUSTOM")
    Vtx.set(result.upper())             #Au début, était sauvegardé en minuscule
#Le nombre de Banks
    result="1"
    if LeModele.upper().find("BANKS_NB=") > -1:
        result=StrExtract.SE(LeModele, "BANKS_NB=", ",", "1")
    Valorise(w.SbxNbBanks, result)
#Wait for bind, OrangeTxBlue, DSM Max Throw
    #ChkPositionne.CP(LeModele, "FAILSAFE=YES", che45)
    ChkPositionne.CP(LeModele, "WAIT_FOR_BIND=YES", che31)
    ChkPositionne.CP(LeModele, "ORANGE_TX_BLUE=YES", che32)
    ChkPositionne.CP(LeModele, "DSM_MAX_THROW=YES", che30)
#DSM_THROTTLE_KILL_CH
    result="15"
    if LeModele.upper().find("DSM_THROTTLE_KILL_CH=") > -1:
        result=StrExtract.SE(LeModele, "DSM_THROTTLE_KILL_CH=", ",", "15")
    Valorise(w.SbxDSM_THROTTLE_KILL, result)
    w.LblChkDSM_THROTTLE_KILL.configure(state="normal")
    if int(result) == 0:
        w.LblChkDSM_THROTTLE_KILL.configure(state="disabled")  #Griser LblChkDSM_THROTTLE_KILL
#USE_A7105_CH15_TUNING
    ChkPositionne.CP(LeModele, "USE_A7105_CH15_TUNING=YES", che24)
#BIND_CH
    result="16"
    if LeModele.upper().find("BIND_CH=") > -1:
        result=StrExtract.SE(LeModele, "BIND_CH=", ",", "16")
    Valorise(w.SbxBindCh, result)
    w.LblBindCh.configure(state="normal")       #Griser LblBindCh si < 5
    if int(result) < 5:
        w.LblBindCh.configure(state="disabled")
#Les Spinbox des Force tuning repérés "@..." dans general.txt
    for key in ForceTuningNoms.keys():
        if LeModele.find("@" + ForceTuningNoms[key] + "=") > -1:
            result=StrExtract.SE(LeModele, "@" + ForceTuningNoms[key]+ "=", ",", "0")
            Valorise(key, result)
    cmdForceTuning()
#Les FailSafe
    ChkPositionne.CP(LeModele, "FAILSAFE=YES", che45)
    ChkPositionne.CP(LeModele, "FAILSAFE_SERIAL_ONLY=YES", che10)
    if LeModele.find("@SbxFailSafe=") > -1:
        result=StrExtract.SE(LeModele, "@SbxFailSafe=", ",", "0")
        Valorise(w.SbxFailSafe, result)
    cmdFailSafe()
#Le Spinbox AFHDS2A_LQI
    if LeModele.find("@SbxAfhds2aLqi=") > -1:
        result=StrExtract.SE(LeModele, "@SbxAfhds2aLqi=", ",", "14")
        Valorise(w.SbxAfhds2aLqi, result)
    cmdAfhds2aLqi()
#Sinon GalModif validé par les précédentes actions relatives aux Spinbox
    ModifIndique("General", False)
#Sport_Polling et Chk_Boot_Loader
    ChkPositionne.CP(LeModele, "SPORT_POLLING=YES", che46)
    ChkPositionne.CP(LeModele, "CHK_BOOT_LOADER=YES", che49)
#Global_ID et Cyrf_ID
    result=""
    if LeModele.find("FORCE_GLOBAL_ID=") > -1:
        result=StrExtract.SE(LeModele, "FORCE_GLOBAL_ID=", ",", "")
    Valorise(w.EnyGlobalId, result)
    result=""
    if LeModele.find("FORCE_CYRF_ID=") > -1:
        result=StrExtract.SE(LeModele, "FORCE_CYRF_ID=", ",", "")
    Valorise(w.EnyCyrfId, result)
#Pour terminer, positionne des boutons en fonction de la situation
    WidgetsValidation()


# Adapter les textes de LbfGalConfig et LbfConfigChoix
# En se basant sur "General:1 | Cfg:1 | Bank:1", modifier le No correspondant
# En se basant sur "RC model of Cfg:1 Bank:1"
# pour General ou Cfg(+Bank)
def DisplayLoadedCfg(letype, leobjet):
    tmp1 = bytearray(w.LbfConfigChoix.cget("text"))
    tmp2 = bytearray(w.LbfRcModelConfig.cget("text"))
    #if letype == "Radiobutton":
        #leobjet.configure(bg="light green")
        #tmp1[26] = Vloadbank.get()
        #tmp2[22] = Vloadbank.get()
    if letype == "Cfg":
        tmp1[17] = leobjet
        tmp2[16] = leobjet
        tmp1[26] = Vloadbank.get()
        tmp2[23] = Vloadbank.get()
    if letype == "General":
        tmp1[4] = leobjet
        w.LbfGalConfig.configure(text="General configuration is Cfg" + leobjet)
    w.LbfConfigChoix.configure(text=tmp1)
    w.LbfRcModelConfig.configure(text=tmp2) #"RC model of Cfg:  Bank: ")
    RbtLoadBankGreen()


# Affiche un message à l'aide d'un widget Message
#Note : relheight=0.127 correspond à 4 lignes de texte
def DisplayMsg(Msg, NbLine):
    rh = 0.127 / 4 * NbLine
    w.Message1.place(relx=0.322, rely=0.100, relheight=rh, relwidth=0.390)
    w.Message1.configure(text=Msg)


# Renseigne les widget pour la configuration du RC_model
def DisplayRcModel(LeModele):
#Le protocole du modèle RC
    result = ("NONE")
    if LeModele.find("PROTOCOL=") > -1:
        result=StrExtract.SE(LeModele, "PROTOCOL=", ",", "NONE")
    Valorise(w.EnyProtocol, result)
#Le sous-protocole du modèle RC
    result = ("1")
    if LeModele.find("SUB_PROTOCOL=") > -1:
        result=StrExtract.SE(LeModele, "SUB_PROTOCOL=", ",", "1")
    Valorise(w.EnySubProtocol, result)
#Le RX_num
    result = ("0")
    if LeModele.find("RX_Num=") > -1:
        result=StrExtract.SE(LeModele, "RX_Num=", ",", "0")
    #Vrxnum.set(result)
    Valorise(w.SbxRxNum, result)    
#Le Power
    result = ("P_HIGH")
    if LeModele.find("Power=") > -1:
        result=StrExtract.SE(LeModele, "Power=", ",", "P_HIGH").upper()
    Vpower.set(result)
#L'AutoBind
    result = ("NO")
    if LeModele.find("Auto_Bind=") > -1:
        result=StrExtract.SE(LeModele, "Auto_Bind=", ",", "NO").upper()
    Vautobind.set(result)
#L'Option
    result = ("0")
    if LeModele.find("Option=") > -1:
        result=StrExtract.SE(LeModele, "Option=", ",", "0")
    #Voption.set(result)
    Valorise(w.SbxOption, result)
#Le nom du configurateur
    result = ("stranger")
    if LeModele.find("ConfiguratorName=") > -1:
        result=StrExtract.SE(LeModele, "ConfiguratorName=", ",", "stranger")
    Valorise(w.EnyConfigurateur, result)
#Les FuturX
    result = ("NONE")
    if LeModele.find("FUTUR1=") > -1:
        result=StrExtract.SE(LeModele, "FUTUR1=", ",", "NONE")
    Valorise(w.EnyFutur1, result)

#ici en cour vu
# Charge et affiche general.txt
def File_LoadGeneral(directory):
    with open("./" + directory + "/general.txt", "r") as f:
        Lu=f.readline().strip("\n")             #C'est les informations 		
        Lu=f.readline().strip("\n")             #Parametres pour General configuration
    DisplayGeneral(Lu)
    #w.LblMonitor.configure(text=Lu)
    if directory == "Cfg0":
        #w.LbfGalConfig.configure(text="General configuration is default")
        pass
    else:
        lacfg = directory[-1:]
        DisplayLoadedCfg("General", lacfg)
        #w.LbfGalConfig.configure(text="General configuration is " + directory)
        Vsavcfg.set(lacfg)                  #Cfg à sauvegarder positionnée
        RbtSavCfgGreen()
    f.close()

#ici en cour vu
# Charger un fichier dans une liste
def FileInList(path_fichier, nom_liste, alpha):
    if alpha == False:
        with open("./" + path_fichier, "r") as f:
#La 1ère ligne, c'est les informations d'en-tête
            Lu=f.readline().strip("\n")                 #Lit et supprime le retour chariot
            while Lu <> "":
                Lu=f.readline().strip("\n")         
                if Lu <> "":			    #Ne pas écrire la dernière ligne
                    nom_liste.insert("end", Lu)
        f.close()
    else:
        rcmList = []
        with open("./" + path_fichier, "r") as f:
#La 1ère ligne, c'est les informations d'en-tête
            Lu=f.readline().strip("\n")                 #Lit et supprime le retour chariot
            while Lu <> "":
                Lu=f.readline().strip("\n")            
                if Lu <> "":			    #Ne pas écrire la dernière ligne
                    rcmList.append(Lu)
        f.close()
        for i in sorted(rcmList):
            nom_liste.insert("end", i)
            
#ici en cour vu
# Insère une chaîne (normalement plusieurs lignes) dans un fichier texte
#Note : startstr=1ère ligne (elle ne sera pas écrite)
#endstr=dernière ligne (elle ne sera pas écrite)
#Note : pendant l'opération lecture-écriture les #define proto+RfCnent
#seront remplacés par #undef proto+RfCnent. Les bons #define
#seront revalidés dans RcModelInsertion()
def File_InsertString(nom_fichier, startstr, endstr, insertstr):
    global list_defino
    fw = open("tmp_file.txt", "w")
    Ok1 = False                 #Mis a True quand startstr trouvé
    Lu = "n'importe quoi pour commencer"
    with open(nom_fichier, "r") as fr:
        while Lu <> "":
            Lu=fr.readline()
            remplacer = False
            #print Lu
            if Lu <> startstr:          #C'est une ligne à conserver
                if Ok1 == False:
                    #Si nécessaire remplacer #define proto+RfCnent par #undef proto+RfCnent
                    if (Lu[:7] == "#define") and (Lu[-5:] == "_INO\n"):
                        remplacer = True
                    #Traiter l'exception (l'extension)
                    if Lu[-24:] == "//Include Q2X2 protocol\n":
                        Lu = "#define\tCX10_NRF24L01_INO\n"
                        remplacer = True
                    if (Lu.strip("\n") in list_defino):
                        remplacer = False
                    if remplacer:
                        Lu = Lu.replace("#define", "#undef")
                    fw.write(Lu)
                else:
                    if Lu == endstr:    #C'est la ligne endstr
                        Ok1 = False
            else:                       #C'est la ligne startstr
                fw.write(insertstr)
                Ok1 = True
    #Si je ne ferme pas les fichiers la copie est incomplète
    fr.close()
    fw.close()
    try:
        copyfile("tmp_file.txt", nom_fichier)
    except:
        BadActionInfo("_Config.h : impossible file creation")


# File_LoadCfg
#  FileInList
#   DisplayLoadedCfg
#   RbtSavCfgGreen
#  WidgetsValidation
# Charge et affiche config_bankX.txt
# Note : NoCfg ne sert qu'à positionner les RbtSavCfgX
def File_LoadCfg(directory, NoCfg, NoBank):
    global RcModelListSorted
    rmls = False
    if RcModelListSorted.get() == "1":
        rmls = True
    w.LbxChoisi.delete(0, "end")    #mm (mm annonce une modif), un ajout, etc..
    FileInList(directory + "/config_bank" + NoBank + ".txt", w.LbxChoisi, rmls)
    if directory == "Cfg0":
        pass
    else:
        DisplayLoadedCfg("Cfg", NoCfg)
        w.LblCfgBankChoisi.configure(text="Save in " + directory + " Bank" + NoBank)
        Vsavcfg.set(NoCfg)                  #Cfg à sauvegarder positionnée
        RbtSavCfgGreen()
        Vsavbank.set(NoBank)
        RbtSavBankGreen()
    WidgetsValidation()             #Pour afficher le nb de lignes de la Listbox

#ici en cour vu
# Charger une partie du fichier _Config.h dans un combobox
#Note : le fichier prévu à charger est _Config.h. Ce qui est mis dans
#le combobox c'est les 15 1er car du protocole puis ">" puis le sous-protocole
def File_ProtoInCombobox(nom_fichier, nom_combo, alpha):
    nom_combo.configure(values=[])
    Dep = False
    lesprot = ""
    lachaine = ""
    titre = ""
    lepath = w.LblDirMp2.cget("text") + "/" + nom_fichier
    start = "/* Available protocols and associated sub protocols"
    fin = "*/"
    try:
        with open(lepath, "r") as f:
            Lu= f.readline()
            while Lu <> "":
                Lu=f.readline()
                if Lu.find(fin) <> -1:
                    Dep = False
                if Lu.find(start) <> -1:
                    Dep = True
                else:
                    if Dep == True:
                        #Si c'est un protocole (donc pas un sous-prot)
                        if Lu.find("\t\t") == -1:
                            titre = Lu[1:].strip("\n").ljust(15," ")
                        else:
                            #Ajouter les sous-prot sans les 2 tabulations
                            lesprot = lesprot + titre + ">" + Lu[2:]
        NewList = lesprot.split("\n")
        f.close()
    except:
        BadActionInfo("Denied access to Multiprotocol directory. " + \
        "Click [Indicate] then [Save config.], restart the program.")
        return 0
    if alpha == False:
        nom_combo.configure(values=NewList)
    else:
        nom_combo.configure(values=sorted(NewList))
        
#ici en cour vu
# Lit configuration.txt
def File_ReadConfiguration():
    global MinMaxAuto, RcModelListSorted, ProtoSubProtoListSorted
    try:
        rep = w.LblDirMp2.cget("text")
        with open("./Cfg0/configuration.txt", "r") as f:
            Lu=f.readline().strip("\n")     #C'est les informations d'en-tête
            Lu=f.readline().strip("\n")     #Nom de Cfg1
            Valorise(w.EnyCfg1, Lu)
            Lu=f.readline().strip("\n")     #Nom de Cfg2
            Valorise(w.EnyCfg2, Lu)
            Lu=f.readline().strip("\n")     #Nom de Cfg3
            Valorise(w.EnyCfg3, Lu)
            Lu=f.readline().strip("\n")     #Rep de MP
            w.LblDirMp2.configure(text = Lu)
            Lu=f.readline().strip("\n")     #Valeur de MinMaxAuto
            if Lu == "MinMaxAuto=":         #Si MinMaxAuto mal sauvegardé
                Lu = "MinMaxAuto=0"
            MinMaxAuto.set(Lu[-1:])
            Lu=f.readline().strip("\n")     #Pour RcModelListSorted
            if Lu == "RcModelListSorted=":  
                Lu = "RcModelListSorted=0"
            RcModelListSorted.set(Lu[-1:])
            Lu=f.readline().strip("\n")      #Pour ProtoSubProtoListSorted
            if Lu == "ProtoSubProtoListSorted=":
                Lu = "ProtoSubProtoListSorted=0"
            ProtoSubProtoListSorted.set(Lu[-1:])
            Lu=f.readline().strip("\n")      #Pour la langue
            LangEnglish.set("1")
            if Lu == "LangFrench=":
                Lu = "LangFrench=0"
            LangFrench.set(Lu[-1:])
            if LangFrench.get() == "1":
                LangEnglish.set("0")
        f.close()
    except:
        BadActionInfo('Corrupted or non-existent file \"configuration.txt\"')

#ici en cour vu
# Remplace une ligne d'un fichier texte après l'avoir sauvegardé s'il
# n'a pas déjà été sauvegardé (il faut conserver une copie de l'original)
def File_ReplaceString(nom_fichier, badstr, goodstr):
    lepath = w.LblDirMp2.cget("text") + "/" + nom_fichier
    ladest = w.LblDirMp2.cget("text") + "/copy_" + nom_fichier
    try:                    #Ne pas sauvegarder le fichier plusieurs fois
        fichier = open(ladest , "r")
        fichier.close()
    except:                 #Le fichier n'existe pas, il sera sauvegardé
        copyfile(lepath, ladest)
    fichier = open(lepath , "r")
    tmp = (str(fichier.read())).replace(badstr, goodstr)
    fichier.close()
    f = open(lepath, "w")
    f.write(tmp)
    f.close()

#ici en cour vu
# Renseigner list_Rf_Proto contenant les relation RF components/PROTO_..
#Note : les relations sont dans "Multiprotocol.h"
def File_RfComponent_Proto():
    global list_Rf_Proto
    list_Rf_Proto = []
    lepath = w.LblDirMp2.cget("text") + "/Multiprotocol.h"
    Dep = False
    relations = ""
    start = "enum PROTOCOLS"
    fin = "};"
    Dep = False
    try:
        with open(lepath, "r") as f:
            Lu= f.readline()
            while Lu <> "":
                Lu=f.readline()
                if Lu.find(fin) <> -1:
                    Dep = False
                if Lu.find(start) <> -1:
                    Dep = True
                else:
                    if Dep == True:
                        if Lu.find("A7105") > -1:
                            leproto = StrExtract.SE(Lu, "\tP", "=", "None").strip()
                            relations = relations + "P" + leproto + " @ A7105\n"
                        if Lu.find("CC2500") > -1:
                            leproto = StrExtract.SE(Lu, "\tP", "=", "None").strip()
                            relations = relations + "P" + leproto + " @ CC2500\n"
                        if Lu.find("CYRF6936") > -1:
                            leproto = StrExtract.SE(Lu, "\tP", "=", "None").strip()
                            relations = relations + "P" + leproto + " @ CYRF6936\n"
                        if Lu.find("NRF24L01") > -1:
                            leproto = StrExtract.SE(Lu, "\tP", "=", "None").strip()
                            relations = relations + "P" + leproto + " @ NRF24L01\n"
        list_Rf_Proto = relations.split("\n")
        f.close()
        #print list_Rf_Proto
    except:
        BadActionInfo("Denied access to Multiprotocol.h. " + \
        "Check the Multiprotocol directory")
        return 0

#ici en cour vu
# Sauve la configuration générale dans "general.txt"
def File_SavGeneral(NoRep):
    global Version
#Commencer par vérifier les valeurs
    if ChanelsOrderVerify() == False:       #L'ordre des canaux
        return False
    ChanelsReverseVerifyAndCorrect()        #Les inversions de canaux
    if PpmMinMaxVerify() == False:          #Les min_100 ..
        return False
    if RF_ComponentVerify() == "":          #Les RF_Components (retourne le texte)
        return False
    if Telemetry_ProtocolVerify() == "error":
        return False
#Positionner des chaînes en fonction de l'état de checkbutton
    invert="NO"
    if che42.get() == "1":
        invert = "YES"
    multi_telemetry="NO"
    if che43.get() == "1":
        multi_telemetry = "YES"
    multi_status="NO"
    if che44.get() == "1":
        multi_status = "YES" 
    failsafe="NO"                              #FAILSAFE (ANCIEN STM32)
    if che45.get() == "1":
        failsafe = "YES"
    wait_for_bind="NO"
    if che31.get() == "1":                  #Wait for bind
        wait_for_bind = "YES"
    orange_tx_blue="NO"
    if che32.get() == "1":
        orange_tx_blue = "YES"
    dsm_max_throw="NO"                      #DSM_Max_Throw
    if che30.get() == "1":
        dsm_max_throw = "YES"
    sport_polling="NO"
    if che46.get() == "1":
        sport_polling = "YES"
    use_a7105_ch15_tuning="NO"              #USE_A7105_CH15_TUNING
    if che24.get() == "1":
        use_a7105_ch15_tuning = "YES"##
    chk_boot_loader="NO"
    if che49.get() == "1":
        chk_boot_loader = "YES"
    failsafe_serial_only = "NO"
    if che10.get() == "1":
        failsafe_serial_only = "YES"
#Les Force tuning
    ttForceTuning = ""
    for key in ForceTuningNoms.keys():
        ttForceTuning = ttForceTuning + ",@" + ForceTuningNoms[key] + "=" \
        + key.get()
#Le nom du fichier est fonction de RbtSavCfgX
    NomFichier = "./Cfg" + NoRep + "/general.txt"
#Le contenu du fichier (une seule ligne) soit :
#Informations, ChanelsOrder, ChanelReverse, SERIAL|PPM, MIN_100 et MAX_100,
#MIN_PPM_CHANNELS, MAX_PPM_CHANNELS
#RF_Components (et leurs LowPoxer), Transmitter, TELEMETRY,
#Telemetry_Protocols, Invert, multi_telemetry, multi_status, BANKS_NB,
#FAILSAFE, wait_for_bind, orange_tx_blue, dsm_max_throw, DSM_THROTTLE_KILL_CH, USE_A7105_CH15_TUNING,
#BIND_CH, les ForceTuning, FAILSAFE_SERIAL_ONLY, AFHDS2A_LQI, Others
    modele = "*General   |Configuration No" + NoRep + "    [Order_Channel=" + \
    w.EnyChanelsOrder.get() + ",REVERSE=" + w.EnyChanelsReverse.get() + \
    ",SERIAL|PPM=" + Vsignal.get() + ",MIN_100=" + w.EnyMin100.get() + \
    ",MAX_100=" + w.EnyMax100.get() + ",MIN_PPM_CHANNELS=" + \
    w.SbxMinPpmChannels.get() + ",MAX_PPM_CHANNELS=" + w.SbxMaxPpmChannels.get() + \
    ",RF_Component=" + RF_ComponentVerify() + \
    ",Transmitter=" + Vtx.get() + ",TELEMETRY=" + Vtelemetry.get() + \
    ",Telemetry_Protocol=" + Telemetry_ProtocolVerify() + ",Telemetry_Invert=" + \
    invert + ",TELEMETRY_MULTI=" + multi_telemetry + ",TELEMETRY_STATUS=" + \
    multi_status + ",BANKS_NB=" + w.SbxNbBanks.get() + \
    ",WAIT_FOR_BIND=" + wait_for_bind + ",ORANGE_TX_BLUE=" + orange_tx_blue + \
    ",DSM_MAX_THROW=" + dsm_max_throw + ",DSM_THROTTLE_KILL_CH=" + \
    w.SbxDSM_THROTTLE_KILL.get() + \
    ",USE_A7105_CH15_TUNING=" + use_a7105_ch15_tuning + \
    ",BIND_CH=" + w.SbxBindCh.get() + ttForceTuning + \
    ",SPORT_POLLING=" + sport_polling + ",FORCE_GLOBAL_ID=" + \
    w.EnyGlobalId.get() + \
    ",FORCE_CYRF_ID=" + w.EnyCyrfId.get() + ",CHK_BOOT_LOADER=" + chk_boot_loader + \
    ",FAILSAFE=" + failsafe + \
    ",FAILSAFE_SERIAL_ONLY=" + failsafe_serial_only + ",@SbxFailSafe=" + \
    w.SbxFailSafe.get() + ",@SbxAfhds2aLqi=" + w.SbxAfhds2aLqi.get() + \
    ",Others=" + w.EnyOthers.get() + "]"
#Créer le fichier de sauvegarde
    try:
        f = open(NomFichier,'w')
        f.write(Version + "\n")
        f.write(modele)
        f.close()
        return True
    except:
        BadActionInfo("No created file")
        return False

#ici en cour vu
# Sauvegarde la liste dans CfgX/config_bankX.txt
def File_SavRcModels(NoRep, NoBank):   
#Le nom du fichier est fonction des RbtSavCfgX et des RbtSavBankX
    global Version
    NomFichier = "./Cfg" + NoRep + "/config_bank" + NoBank + ".txt"
    tmp1 = "".join(w.LbxChoisi.get(0, "end"))
    tmp2 = tmp1.replace("*", "\n*")
    tmp1 = Version + tmp2
    try:
        f = open(NomFichier,'w')
        f.write(tmp1)
        f.close()
        return True
    except:
        return False


#Affiche un message d'aide
def HelpInfo(message):
    w.LblHelpInfo2.configure(text=message)
 
    
# Initialisation lors de l'ouverture du module
def init(top, gui, *args, **kwargs):
    global w, top_level, root
    global GalModif, RcmModif
    w = gui             #Donc w est issu de la classe TopLevel1
    top_level = top     #Donc top_level est issu de la classe Tkinter la plus haute
    root = top          #Donc root est issu de la classe Tkinter la plus haute
#Demander avant de quitter
    top_level.protocol("WM_DELETE_WINDOW", QuitYesNo)
#Indiquer le répertoire de travail
    w.LblDirCur2.configure(text=os.getcwd())    
#Pour l'ordre des canaux, toutes les possibilités
    global TtChOrder
    TtChOrder=("TREA","TRAE","TERA","TEAR","TARE","TAER",
    "RTEA","RTAE","RETA","REAT","RATE","RAET",
    "ETRA","ETAR","ERTA","ERAT","EATR","EART",
    "ATRE","ATER","ARTE","ARET","AETR","AERT")
#Pour associer les Force tuning à leurs labels
    global ForceTuningLabels       #Dictionnaire des Force tuning - Labels
    ForceTuningLabels = \
    {w.SbxCORONA:w.LblCORONA , w.SbxFRSKYX:w.LblFRSKYX , \
    w.SbxFRSKYD:w.LblFRSKYD , w.SbxSFHSS:w.LblSFHSS , \
    w.SbxFRSKYV:w.LblFRSKYV , w.SbxHITEC:w.LblHITEC , \
    w.SbxFLYSKY:w.LblFLYSKY , w.SbxHUBSAN:w.LblHUBSAN , \
    w.SbxAFHDS2A:w.LblAFHDS2A , w.SbxBUGS:w.LblBUGS }
#Pour associer les Force tuning à leurs noms
    global ForceTuningNoms          #Dictionnaire des Force tuning - Noms
    ForceTuningNoms = \
    {w.SbxCORONA:"SbxCORONA" , w.SbxFRSKYX:"SbxFRSKYX" , \
    w.SbxFRSKYD:"SbxFRSKYD" , w.SbxSFHSS:"SbxSFHSS" , \
    w.SbxFRSKYV:"SbxFRSKYV" , w.SbxHITEC:"SbxHITEC" , \
    w.SbxFLYSKY:"SbxFLYSKY" , w.SbxHUBSAN:"SbxHUBSAN" , \
    w.SbxAFHDS2A:"SbxAFHDS2A" , w.SbxBUGS:"SbxBUGS" }
#Pour les valeurs par défaut des Min et Max PPM
    global DefaultMinMax            #Dictionnaire des Min et Max PPM
    DefaultMinMax = \
    {"DEVO7":["1120","1920"] , "ER9X":["988","2012"] , \
    "HISKY":["1120","1920"] ,  "SPEKTRUM":["1100","1900"] , \
    "TX_MPX":["1250","1950"] , "WALKERA":["1000","1800"] , \
    "CUSTOM":["1100","1900"] , "FUTUR1":["1000","2000"] }
#Pour associer les Checkbox de RF_components à leurs désignations
    global DicoRfCnentDesign  #Dico des RF_components/Chk correspondants
    DicoRfCnentDesign = \
    {"A7105":che74 , "CYRF6936":che75 , \
    "CC2500":che76, "NRF24L01":che77 }
#Pour les LEDs
    global LEDs                     #liste des LEDs et LblCfgX
    LEDs = [w.LblCfg1Gal, w.LblCfg2Gal,w.LblCfg3Gal, \
    w.LblCfg1RcModel, w.LblCfg2RcModel, w.LblCfg3RcModel, \
    w.LblCfg1, w.LblCfg2, w.LblCfg3]
#Pour les modifications
    GalModif = False
    RcmModif = False
#Préparer des widgets
    Default_Values()
#Les options de Save In 
    RbtSavCfgGreen()
    RbtSavBankGreen()
#Lire le fichier configuration.txt contenant les noms des configurations
    File_ReadConfiguration()
#Bank No1 par défaut
    Vloadbank.set("1")
    RbtLoadBankGreen()
#Configuration générale + affichage des RC model, par défaut
    File_LoadGeneral("Cfg1")
    File_LoadCfg("Cfg1","1","1")
#Renseigner CbxProtocoles avec les protocoles et sous-protocoles de _Config.h
    global ProtoSubProtoListSorted
    SortedProto = False
    if ProtoSubProtoListSorted.get() == "1":
        SortedProto = True
    File_ProtoInCombobox("_Config.h", w.CbxProtocoles, SortedProto)
#Pour créer la liste des relations RF components et PROTO
    File_RfComponent_Proto()
#Choisir la langue
    global LangFrench, LangEnglish
    #french = False
    LangEnglish.set("1")
    if LangFrench.get() == "1":
        LangEnglish.set("0")
#Décaler la fenêtre, c'est plus partique pour travailler
    top.geometry("897x567+350+29")          #aeff à la fin
#Compenser les manques de Tkinter
    root.option_add("*font", "Courier 8")   #Bonne fonte pour TCombobox
    w.CbxProtocoles.configure(height=14)
    w.LbxChoisi.configure(exportselection=False)    #Conserver l'index de lligne sélectionnée
#Compenser les erreurs de Page generator
    w.imgSavGen = tk.PhotoImage(file="./images/save.gif")
    w.BtnSavGal2.configure(image=w.imgSavGen)
    #w.imgSavGen = tk.PhotoImage(file="images/save.gif")
    w.BtnSavRcModel2.configure(image=w.imgSavGen)
    w.BtnSavConfig2.configure(image=w.imgSavGen)
    w.imgArduino = tk.PhotoImage(file="./images/arduino.gif")
    w.BtnSynthese2.configure(image=w.imgArduino)
    w.imgEn = tk.PhotoImage(file="./images/en.gif")
    w.sub_menu12.entryconfigure("0", image=w.imgEn)
    w.imgFr = tk.PhotoImage(file="./images/fr.gif")
    w.sub_menu12.entryconfigure("1", image=w.imgFr)
    w.imgUp = tk.PhotoImage(file="./images/up.gif")
    w.BtnUp2.configure(image=w.imgUp)
    w.imgDown = tk.PhotoImage(file="./images/down.gif")
    w.BtnDown2.configure(image=w.imgDown)
#Redimensionner et cacher Message1
    w.Message1.place(x=260, y=210, height=229, width=344)
    w.Message1.configure(width=344)
    w.Message1.place_forget()
#Redimensionner et cacher LbfAddInfo
    w.LbfAddInfo.place(x=70, y=175, height=117, width=760)
    #w.LbfAddInfo.configure(width=760)
    w.LbfAddInfo.place_forget()
    w.LblAddInfo.place(x=10, y=15, height=94, width=741)
    #w.LbfAddInfo.place_forget()
    

# Allume LED concernée et éteint les autres de même type
#Note : lelabel c'est la LED, si lelabel=None les LEDs correspondant à
#letype sont éteintes et aucune n'est allumée
#Note : gère aussi la couleur des LblCfgX
def LedOnOff(lelabel, legenre):
    global LEDs
    for i in range(6,9):                    #Les LblCfgX
        LEDs[i].configure(bg="#d9d9d9")
    if legenre.find("General") > -1:        #Les LEDs des LblCfgXGal
        for i in range(0,3):                #Les LEDs des LblCfgXRcModel
            LEDs[i].configure(bg="gray")
    if legenre.find("RcModel") > -1:
        for i in range(3,6):
            LEDs[i].configure(bg="gray")
    if lelabel == None:
        return 0
    lelabel.configure(bg="light green")
    for i in range(0,3):                    #Les couleurs des LblCfgX
        if LEDs[i].cget("bg") == "light green" or \
        LEDs[i+3].cget("bg") == "light green":
            LEDs[i+6].configure(bg="light green")


# Limiter le nb de car dans un widget Entry
def LimitLen(nom_entry, nbcar, message, bip):
    tmp=nom_entry.get()
    if len(tmp) > nbcar:
        BadActionInfo(message)        
        if bip == True:
            print ("\a")
        Valorise(nom_entry, tmp[0:nbcar])


# Ajoute ou retire " [*]" au text d'un labelframe
def ModifIndique(letype, Star):
    #print("def ModifIndique")
    global GalModif, RcmModif, VtxMem, VsignalMem, VtelemetryMem, VautobindMem, VpowerMem
    if letype == "General":
        lachaine = w.LbfGalConfig.cget("text")
        if Star:        #Ajouter [*] après le texte
            if lachaine.find("[*]") == -1:
                w.LbfGalConfig.configure(text=lachaine + " [*]")
            GalModif = True
        else:           #Enlever [*] en fin de texte
            if lachaine.find("[*]") > -1:
                w.LbfGalConfig.configure(text=lachaine[:len(lachaine)-4])
            GalModif = False
            VtxMem = Vtx.get()
            VsignalMem = Vsignal.get()
            VtelemetryMem = Vtelemetry.get()
    else:                               #Rc model
        lachaine = w.LbfRcModelConfig.cget("text")
        if Star:
            if lachaine.find("[*]") == -1:
                w.LbfRcModelConfig.configure(text=lachaine + " [*]")
            RcmModif = True
        else:
            if lachaine.find("[*]") > -1:
                w.LbfRcModelConfig.configure(text=lachaine[:len(lachaine)-4])
            RcmModif = False
            VautobindMem = Vautobind.get()
            VpowerMem = Vpower.get()
        
  
# Verifie si les min_100.. sont numériques et s'ils existent
#Note : retourne False si :
#- Min ou Max ou Nb channel Min ou Nb channel Max ne sont pas des nombres entiers
#- Min ou Max sont hors limites
#- Nb channel Min > Nb channel Max
def PpmMinMaxVerify():
    bon = True
    try:
        if w.EnyMin100.get().isdigit() == False:
            BadActionInfo("PPM, min_100 value error")
            bon = False
        if int(w.EnyMin100.get()) < 800 or int(w.EnyMin100.get()) > 1200:
            BadActionInfo("Min_100 : value out of bounds")
            bon = False
        if w.EnyMax100.get().isdigit() == False:
            BadActionInfo("PPM, max_100 value error")
            bon =False
        if int(w.EnyMax100.get()) < 1800 or int(w.EnyMax100.get()) > 2200:
            BadActionInfo("Max_100 : value out of bounds")
            bon = False
        if w.SbxMinPpmChannels.get().isdigit() == False:
            BadActionInfo("MinNbChannels value error")
            bon = False
        if w.SbxMaxPpmChannels.get().isdigit() == False:
            BadActionInfo("MaxNbChannels value error")
            bon = False
        if int(w.SbxMinPpmChannels.get()) > int(w.SbxMaxPpmChannels.get()):
            BadActionInfo("MinNbChannels is greater than MaxNbChannels")
            bon = False
    except:
        bon = False
        
#Tolérance : correction des mauvaises valeurs si c'est le mode Serial
    if (bon == False) and (Vsignal.get() == "SERIAL" ):
        Valorise(w.EnyMin100, "1100")
        Valorise(w.EnyMax100, "1900")
        Valorise(w.SbxMinPpmChannels, "4")
        Valorise(w.SbxMaxPpmChannels, "16")
        DisplayMsg("The erroneous values ​​for PPM have been corrected since \
the chosen mode is Serial" , 5)
        bon = True
        
    return bon
#ici en cour

# Demander avant de quitter ce programme
def QuitYesNo():
    destroy_window()


# Retourne le contenu des 5 Bank de MUI ou "FAUX" si problème trouvé
#Note : vérifie en même temps les relations PROTO/RF_components
#Note : traite section "PROTOCOLS TO INCLUDE" pour les #define ...INO
def RcModelInsertion():
    global RcmModif, list_Rf_Proto
    global list_defino              #Liste des #define proto+RfCnent.INO
    list_defino = []
    defino = ""
    BadAction = False
    if RcmModif:
        BadActionInfo("Save configuration before running the synthesis")
        return "FAUX"
    NoBankMem = Vloadbank.get()         #Mémoriser la bank actuelle
    NSBankMem = Vsavbank.get()
    NoCfg = str(Vsavcfg.get())
    directory = "Cfg" + NoCfg
    LesCfg = ""
    for NbBank in range (1,6):
        NoBank = str(NbBank)
        LesCfg = LesCfg + "#if NBR_BANKS > " + str(NbBank-1) + "\n" + \
        "//******************************  " + "Bank " + NoBank + \
        "  ****************************** (MUI " + directory + ")\n" + \
        "// Switch   Protocol        Sub     RX_Num	Power" + \
        "   Auto_Bind	Option\n"
        File_LoadCfg(directory, NoCfg, NoBank)
        n = 0
        for item in w.LbxChoisi.get(0, "end"):
            n += 1
#********** Vérifier la relation PROTO/RF_component **********
            leproto = StrExtract.SE(item, "PROTOCOL=", ",", "NOT_FIND")
            #Ex:leproto="PROTO_FLYSKY"
            if leproto == "NOT_FIND":
                leproto = "PROTO_FLYSKY"
            else:
                RfComponent = StrListExtration(list_Rf_Proto, leproto+" @ ")
                #Ex:RfComponent="A7105"
                defino = "#define\t" + leproto[6:] + "_" + RfComponent + "_INO"
                if (DicoRfCnentDesign[RfComponent]).get() <> "1":
                #Ex:teste che74 <>
#Use BadAction for report only the first forgetting
                    if BadAction == False:
                        BadActionInfo("For " + leproto + \
                        " you may have forgotten the " + RfComponent + \
                        " Checkbutton")
                        BadAction = True
#Traiter l'exception (extension)
            if defino == "define\tQ2X2_NRF24L01_INO":
                defino = "define\tCX10_NRF24L01_INO"
            if (defino in list_defino) == False:
                list_defino.append(defino)
#********** Vérifier la relation PROTO/RF_component **********
            LesCfg = LesCfg + "/*  " + str(n).zfill(2) + "  */\t{" + \
            leproto + ",\t" + \
            StrExtract.SE(item, "SUB_PROTOCOL=", ",", "Flysky") + ",\t" + \
            StrExtract.SE(item, "RX_Num=", ",", "0") + ",\t" + \
            StrExtract.SE(item, "Power=", ",", "P_HIGH") + ",\t"
            autobind = "AUTOBIND"
            result=StrExtract.SE(item, "Auto_Bind=", ",", "NO")
            if result == "NO":
                autobind = "NO_AUTOBIND"
            LesCfg = LesCfg + autobind + ",\t" + \
            StrExtract.SE(item, "Option=", ",", "0") + "\t}, //"
            LesCfg = LesCfg + item[:32] + "\n"
        if n < 14:
            for i in range(n,14):
                LesCfg = LesCfg + "/*  XX  */	{PROTO_FLYSKY,	" + \
                "Flysky,	0,	P_HIGH,	NO_AUTOBIND,	" + \
                "0	}, //*None      |None\n"
        LesCfg = LesCfg + "#endif\n"
    LesCfg = LesCfg + "};\n"
#Récupérer l'affichage d'avant le lancement de cette fonction
    File_LoadCfg(directory, NoCfg, NoBankMem)
    Vsavbank.set(NSBankMem)
    cmdRbtSavBank()
#Retourner le résultat d ecette fonction
    return LesCfg


#Enlève les doublons saisis pour les Reverse
def ReverseCorrige (LaChaine):
    GoodReverse=""
    for char in "AETR":
        if LaChaine.find(char) > -1:
            GoodReverse = GoodReverse + char
    return GoodReverse


# Vérifie si au moins un RF_Component est choisi et retourne les noms
# de RF_Components choisis et les LowPower correspondants
def RF_ComponentVerify():
    ttRF_Components = ""
    if che74.get() == "1":
        ttRF_Components = "*A7105"
        if che20.get() == "1":
            ttRF_Components = ttRF_Components + "-A7105"
    if che75.get() == "1":
        ttRF_Components = ttRF_Components + "*CYRF6936"
        if che21.get() == "1":
            ttRF_Components = ttRF_Components + "-CYRF6936"
    if che76.get() == "1":
        ttRF_Components = ttRF_Components + "*CC2500"
        if che22.get() == "1":
            ttRF_Components = ttRF_Components + "-CC2500"
    if che77.get() == "1":
        ttRF_Components = ttRF_Components + "*NRF24L01"
        if che23.get() == "1":
            ttRF_Components = ttRF_Components + "-NRF24L01"
    if ttRF_Components == "":
        BadActionInfo("At least one RF_Component is needed")           
        return ""
    else:
        return ttRF_Components


# Dans une liste, recherche lachaine et retourne son complément
#Note : utilisée par RcModelInsertion
def StrListExtration(laliste, lachaine):
    global list_Rf_Proto #aeff
    tmp = ""
    for item in list_Rf_Proto:
	if item.find(lachaine) > -1:
            tmp = item[len(lachaine):]
    return tmp


#Extraction dans "chaine" par les delimiteurs "avant" et "apres".
#Si le resultat est vide ou en cas d'erreur, "v_defaut" est retourné.
#Note : dysfonctionnement si"apres" est le dernier caractère de "chaine"
""" def StrExtract.SE(chaine, avant, apres, v_defaut):
    dep=chaine.find(avant)
    if dep == -1:
        return v_defaut
    lon = len(avant)
    fin = chaine.find(apres , dep)
    trouve=chaine[dep+lon:fin]
    try:
        trouve=chaine[dep+lon:fin]
        if trouve == "":
            trouve=v_defaut
    except:
        trouve=v_defaut
    return trouve """

#ici en cour vu
# Créer _MyConfig.h avec les nouveaux codes
#  File_ReplaceString() pour "#define USE_MY_CONFIG" dans _Config.h
#  ToInsert = RcModelInsertion() pour créer les 5 MUI bank
#   Renseigne list_defino avec les #define ...INO nécessaires de,
#   la section "PROTOCOLS TO INCLUDE".
#   Teste relations PROTO/RF_components pour vérif si RF_Component pas oublié,
#   en utilisant StrListExtration().
#  File_InsertString(.. ToInsert) pour insérer les Bank dans _Config.h.
#   En même temps, remplace les #define ...INO par #undef ...INO,
#   sauf si les #define ...INO existent dans list_defino.
def Synthese():
    w.LblSynthesize.configure(bg="red")
########## _MyConfig.h #########
    lepath = w.LblDirMp2.cget("text") + "/_MyConfig.h"
    MyConfig = "// Generated by MUI\n"
#Channels order
    MyConfig = MyConfig + "#undef AETR\n" + "#define " + \
    w.EnyChanelsOrder.get() + "\n"
#Channels reverse
    if (w.EnyChanelsReverse.get()).find("A") > -1:
        MyConfig = MyConfig + "#define REVERSE_AILERON\n"
    if (w.EnyChanelsReverse.get()).find("E") > -1:
        MyConfig = MyConfig + "#define REVERSE_ELEVATOR\n"
    if (w.EnyChanelsReverse.get()).find("T") > -1:
        MyConfig = MyConfig + "#define REVERSE_THROTTLE\n"
    if (w.EnyChanelsReverse.get()).find("R") > -1:
        MyConfig = MyConfig + "#define REVERSE_RUDDER\n"
#DSM_MAX_THROW
    if che30.get() == "1":
        MyConfig = MyConfig + "#define DSM_MAX_THROW\n"
#DSM_THROTTLE_KILL_CH
    i = int(w.SbxDSM_THROTTLE_KILL.get())
    if i == 0:
        MyConfig = MyConfig + "#undef DSM_THROTTLE_KILL_CH\n"
    else:
        MyConfig = MyConfig + "#define DSM_THROTTLE_KILL_CH    " + str(i) + "\n"
#BIND_CH
    i = int(w.SbxBindCh.get())
    if i < 5:
        MyConfig = MyConfig + "#undef ENABLE_BIND_CH\n"
        MyConfig = MyConfig + "#undef BIND_CH\n"
    else:
        MyConfig = MyConfig + "#define ENABLE_BIND_CH\n"
        MyConfig = MyConfig + "#define BIND_CH	" + str(i) + "\n"
#WAIT_FOR_BIND
    if che31.get() <> "1":
        MyConfig = MyConfig + "#undef WAIT_FOR_BIND\n"
#USE_A7105_CH15_TUNING
    MyConfig = Synthese_Sub2(che24, MyConfig, "USE_A7105_CH15_TUNING")        
#Les RF components
    MyConfig = Synthese_Sub2(che74, MyConfig, "A7105_INSTALLED")
    MyConfig = Synthese_Sub2(che75, MyConfig, "CYRF6936_INSTALLED")
    MyConfig = Synthese_Sub2(che76, MyConfig, "CC2500_INSTALLED")
    MyConfig = Synthese_Sub2(che77, MyConfig, "NRF24L01_INSTALLED")
#OrangeRX
    MyConfig = Synthese_Sub2(che32, MyConfig, "ORANGE_TX_BLUE")
#Les force tuning
    MyConfig = Synthese_Sub1(w.SbxCORONA, MyConfig, "FORCE_CORONA_TUNING")
    MyConfig = Synthese_Sub1(w.SbxFRSKYD, MyConfig, "FORCE_FRSKYD_TUNING")
    MyConfig = Synthese_Sub1(w.SbxFRSKYV, MyConfig, "FORCE_FRSKYV_TUNING")  
    MyConfig = Synthese_Sub1(w.SbxFRSKYX, MyConfig, "FORCE_FRSKYX_TUNING")
    MyConfig = Synthese_Sub1(w.SbxSFHSS, MyConfig, "FORCE_SFHSS_TUNING")
    MyConfig = Synthese_Sub1(w.SbxHITEC, MyConfig, "FORCE_HITEC_TUNING")
    MyConfig = Synthese_Sub1(w.SbxAFHDS2A, MyConfig, "FORCE_AFHDS2A_TUNING")
    MyConfig = Synthese_Sub1(w.SbxBUGS, MyConfig, "FORCE_BUGS_TUNING")
    MyConfig = Synthese_Sub1(w.SbxFLYSKY, MyConfig, "FORCE_FLYSKY_TUNING")
    MyConfig = Synthese_Sub1(w.SbxHUBSAN, MyConfig, "FORCE_HUBSAN_TUNING")
#Les LOW_POWER
    MyConfig = Synthese_Sub2(che20, MyConfig, "A7105_ENABLE_LOW_POWER")
    MyConfig = Synthese_Sub2(che21, MyConfig, "CYRF6936_ENABLE_LOW_POWER")
    MyConfig = Synthese_Sub2(che22, MyConfig, "CC2500_ENABLE_LOW_POWER")
    MyConfig = Synthese_Sub2(che23, MyConfig, "NRF24L01_ENABLE_LOW_POWER")
#TELEMETRY
    MyConfig = Synthese_Sub3(Vtelemetry, "YES", MyConfig, "TELEMETRY")
    MyConfig = Synthese_Sub2(che44, MyConfig, "MULTI_STATUS")
    MyConfig = Synthese_Sub2(che43, MyConfig, "MULTI_TELEMETRY")
    MyConfig = Synthese_Sub2(che50, MyConfig, "AFHDS2A_FW_TELEMETRY")
    MyConfig = Synthese_Sub2(che57, MyConfig, "AFHDS2A_HUB_TELEMETRY")    
    MyConfig = Synthese_Sub2(che51, MyConfig, "BAYANG_HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che58, MyConfig, "BUGS_HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che52, MyConfig, "CABELL_HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che59, MyConfig, "DSM_TELEMETRY")
    MyConfig = Synthese_Sub2(che53, MyConfig, "HITEC_FW_TELEMETRY")
    MyConfig = Synthese_Sub2(che60, MyConfig, "HITEC_HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che54, MyConfig, "HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che61, MyConfig, "HUBSAN_HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che55, MyConfig, "NCC1701_HUB_TELEMETRY")
    MyConfig = Synthese_Sub2(che62, MyConfig, "SPORT_TELEMETRY")
#Sport_Polling, Global_ID, Cyrf_ID, Chk_Boot_Loader
    MyConfig = Synthese_Sub2(che46, MyConfig, "SPORT_POLLING")
#Les force ID
    if w.EnyGlobalId.get() == "":
        MyConfig = MyConfig + "#undef FORCE_GLOBAL_ID\n"
    else:
        MyConfig = MyConfig + "#define FORCE_GLOBAL_ID " + \
        w.EnyGlobalId.get() + "\n"
    if w.EnyCyrfId.get() == "":
        MyConfig = MyConfig + "#undef FORCE_CYRF_ID\n"
    else:
        MyConfig = MyConfig + "#define FORCE_CYRF_ID " + \
        w.EnyCyrfId.get() + "\n"    
#CHECK_FOR_BOOTLOADER
    MyConfig = Synthese_Sub2(che49, MyConfig, "CHECK_FOR_BOOTLOADER")
#SERIAL
    MyConfig = Synthese_Sub3(Vsignal, "SERIAL", MyConfig, "ENABLE_SERIAL")
    MyConfig = Synthese_Sub3(Vsignal, "PPM", MyConfig, "PPM")
#Vérification pour PPM
    if PpmMinMaxVerify() == False:
        return 0
#Les END POINTS et PPM_MIN_100 PPM_MAX_100
#Je décide que l'utilisateur choisit les valeurs. Donc TX_CUSTOM est imposé
    MyConfig = MyConfig + "#undef TX_ER9X\n"
    MyConfig = MyConfig + "#define TX_CUSTOM\n"
    MyConfig = MyConfig + "#define PPM_MAX_100 " +  w.EnyMax100.get() + "\n"
    MyConfig = MyConfig + "#define PPM_MIN_100 " +  w.EnyMin100.get() + "\n"
#MIN_PPM_CHANNELS et MAX_PPM_CHANNELS
    #if PpmMinMaxVerify() == False:
        #return 0
    MyConfig = Synthese_Sub1(w.SbxMinPpmChannels, MyConfig, "MIN_PPM_CHANNELS")
    MyConfig = Synthese_Sub1(w.SbxMaxPpmChannels, MyConfig, "MAX_PPM_CHANNELS")
#NBR_BANKS
    MyConfig = Synthese_Sub1(w.SbxNbBanks, MyConfig, "NBR_BANKS")
#Les FailSafe
#Si FailSafe alors FailSafe (throttle low) est valisé et FailSafe Serial Only,
#prend sa valeur choisie.
#Si Not FailSafe aucun FailSafe validé.
    i = int(w.SbxFailSafe.get()) 
    if che45.get() == "1":
        MyConfig = MyConfig + "#define FAILSAFE_ENABLE\n"
        if che10.get() == "1":
            MyConfig = MyConfig + "#define FAILSAFE_SERIAL_ONLY\n"
        else:
            MyConfig = MyConfig + "#undef FAILSAFE_SERIAL_ONLY\n"
        MyConfig = MyConfig + "#define FAILSAFE_THROTTLE_LOW " + str(i) + "\n"
    else:
        MyConfig = MyConfig + "#undef FAILSAFE_ENABLE\n"
        MyConfig = MyConfig + "#undef FAILSAFE_SERIAL_ONLY\n"
        MyConfig = MyConfig + "#undef FAILSAFE_THROTTLE_LOW\n"
#AFHDS2A_LQI_CH
    i = int(w.SbxAfhds2aLqi.get())
    if i > 4:
        MyConfig = MyConfig + "#define AFHDS2A_LQI_CH " + str(i) + "\n"
    else:
        MyConfig = MyConfig + "#undef AFHDS2A_LQI_CH\n"
#Enregistrer _MyConfig.h
    f = open(lepath, "w")
    f.write(MyConfig)
    f.close()
########## _MyConfig.h #########

########## _Config.h ###########
#Indiquer que pour les paramètres ci-dessus c'est MyCongig.h qui prend la main
    File_ReplaceString("_Config.h", "//#define USE_MY_CONFIG" ,\
    "#define USE_MY_CONFIG\t//For use the MUI _MyConfig.h")
#Remplacer les Bank dans _Config.h
    lepath = w.LblDirMp2.cget("text") + "/_Config.h"
    startstr = "#if NBR_BANKS > 0\n"
    endstr ="};\n"
    ToInsert = RcModelInsertion()
    if ToInsert == "FAUX": 
        return 0
    File_InsertString(lepath, startstr, endstr, ToInsert)
    HelpInfo("[Synthesize] = _MyConfig.h is created and _Config.h is adapted !")
    w.LblSynthesize.configure(bg="light green")
########## _Config.h ###########

# Pour suppléer Synthese. Positionnement des Radiobutton
#Note : en fonction de la valeur de Variable du Radiobutton, renseigne lachaine.
def Synthese_Sub3(leradiobutton, goodvalue, lachaine, mpcode):
    if leradiobutton.get() <> goodvalue:
        ledef="#undef "
    else:
        ledef="#define "
    lachaine = lachaine + ledef + mpcode + " \n"
    return lachaine
# Pour suppléer Synthese. Positionnement des Checkbutton
#Note : en fonction de la valeur du Checkbox, renseigne lachaine.
def Synthese_Sub2(leche, lachaine, mpcode):
    if leche.get() <> "1":
        ledef="#undef "
    else:
        ledef="#define "
    lachaine = lachaine + ledef + mpcode + " \n"
    return lachaine
# Pour suppléer Synthese. Pour les Spinbox
#Note : en fonction de la valeur du Spinbox, renseigne lachaine.
def Synthese_Sub1(lesbx, lachaine, mpcode):
    pass
    i = int(lesbx.get())
    if i == 0:
        lachaine = lachaine + "#undef " + mpcode + "\n"          
    else:
        lachaine = lachaine + "#define " + mpcode + " " + str(i) + "\n" 
    return lachaine


#Il faut un moins un protocole si la télémétrie est validée
# Note : retourne les protocoles validés
def Telemetry_ProtocolVerify():
    ttProt = ""
    if che50.get() == "1":
        ttProt = "*AFHDS2A_FW"
    if che51.get() == "1":
        ttProt = ttProt + "*BAYANG_HUB"
    if che52.get() == "1":
        ttProt = ttProt + "*CABELL_HUB"
    if che53.get() == "1":
        ttProt = ttProt + "*HITEC_FW"
    if che54.get() == "1":
        ttProt = ttProt + "*HUB"
    if che55.get() == "1":
        ttProt = ttProt + "*NCC1701_HUB"
    if che56.get() == "1":
        ttProt = ttProt + "*FUTUR1"
    if che57.get() == "1":
        ttProt = ttProt + "*AFHDS2A_HUB"
    if che58.get() == "1":
        ttProt = ttProt + "*BUGS_HUB"
    if che59.get() == "1":
        ttProt = ttProt + "*DSM"
    if che60.get() == "1":
        ttProt = ttProt + "*HITEC_HUB"
    if che61.get() == "1":
        ttProt = ttProt + "*HUBSAN_HUB"
    if che62.get() == "1":
        ttProt = ttProt + "*SPORT"   
    if che63.get() == "1":
        ttProt = ttProt + "*FUTUR2"   

    if Vtelemetry.get()=="YES" and ttProt=="":
        BadActionInfo("If SERIAL, one protocole is required")           
        return "error"
    else:
        return ttProt


# Efface puis insère une valeur(texte) dans un widget
#Note : donner temporairement la valeur "normal" à state sinon
#les widget peuvent ne pas être modifiés
def Valorise(LeWidget, LeTexte):
    lestate = LeWidget.cget("state")
    LeWidget.configure(state="normal")
    LeWidget.delete(0,"end")
    LeWidget.insert(0, LeTexte)
    LeWidget.configure(state=lestate)
    
    
# Valide des boutons en fonction de la situation
def WidgetsValidation():
    global Clipboard
#Les boutons Del RC model et <Clipboard et Up et Down
    DelOk = True
    if w.LbxChoisi.size() == 0 or str(w.LbxChoisi.curselection()) == "()":
        DelOk = False        
    if DelOk == True:
        w.BtnDel.configure(state="normal")
        w.BtnInClipBoard.configure(state="normal")
        w.BtnUp.configure(state="normal")
        w.BtnUp2.configure(state="normal")
        w.BtnDown.configure(state="normal")
        w.BtnDown2.configure(state="normal")
        w.BtnRefresh.configure(state="normal")
        if w.LbxChoisi.curselection() == (0,):
            w.BtnUp.configure(state="disabled")
            w.BtnUp2.configure(state="disabled")
        if w.LbxChoisi.curselection() == (w.LbxChoisi.size()-1,):
            w.BtnDown.configure(state="disabled")
            w.BtnDown2.configure(state="disabled")
    else:
        w.BtnDel.configure(state="disabled")
        w.BtnInClipBoard.configure(state="disabled")
        w.BtnUp.configure(state="disabled")
        w.BtnUp2.configure(state="disabled")
        w.BtnDown.configure(state="disabled")
        w.BtnDown2.configure(state="disabled")
        w.BtnRefresh.configure(state="disabled")
#Le bouton Add, la couleur et le titre de LbfRcModelConfig
    AddOk = True
    if w.EnyBrand.get() == "":
        AddOk=False
    if w.EnyRcModel.get() == "":
        AddOk=False
    if w.EnyProtocol.get() == "":
        AddOk=False
    if w.EnySubProtocol.get() == "":
        AddOk=False
    w.LblNbItem.configure(text = str(w.LbxChoisi.size()) + " line(s)")
    tmp = w.LbfRcModelConfig.cget("text")
    if w.LbxChoisi.size() > 13:         #Le nombre de ligne dans LbxChoisi
        #if tmp.find("(Full)") == -1:
            #tmp = tmp + " (Full)"
        #couleur orange pour signaler que nb lignes > 13
        w.LbfRcModelConfig.configure(fg="#d18800")   #, text=tmp)
        w.LblNbItem.configure(bg="#d18800")
        AddOk=False
        HelpInfo("RC models list : max 14 lines")
    else:
        #if tmp.find("(Full)") > -1:
            #tmp = tmp[:24]
        w.LbfRcModelConfig.configure(fg="black") #, text=tmp)
        w.LblNbItem.configure(bg="#d9d9d9")
    if AddOk == True:
        w.BtnAdd.configure(state="normal")
    else:
        w.BtnAdd.configure(state="disabled")
#Le bouton >Clipboard
    w.BtnInList.configure(state="normal")
    if (w.LbxChoisi.size() > 13) or (Clipboard == ""):
        w.BtnInList.configure(state="disabled")
#Le bouton BtnSavRcModel
    w.BtnSavRcModel.configure(state="disabled")
    if w.LbxChoisi.size() > 0:
        w.BtnSavRcModel.configure(state="normal")


if __name__ == '__main__':
    import MUI.py
    MUI.py.vp_start_gui()





